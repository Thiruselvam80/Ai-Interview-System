import json
import random
import hashlib
from typing import List, Dict, Any, Tuple
import re
from datetime import datetime

class MLQuestionGenerator:
    """Advanced ML-based question generator for programming languages"""
    
    def __init__(self):
        self.question_database = {
            'python': {
                'syntax': [
                    {
                        'question': 'What is the correct syntax for a list comprehension in Python?',
                        'options': ['[x for x in range(10)]', '{x for x in range(10)}', '(x for x in range(10))', '[x in x for range(10)]'],
                        'answer': '[x for x in range(10)]',
                        'explanation': 'List comprehensions use square brackets and follow the pattern [expression for item in iterable]',
                        'difficulty': 'medium',
                        'concepts': ['list_comprehension', 'syntax']
                    },
                    {
                        'question': 'Which of the following correctly defines a function with default parameters?',
                        'options': ['def func(a=5, b):', 'def func(a, b=5):', 'def func(a=5, b=10):', 'def func(a, b=5, c):'],
                        'answer': 'def func(a, b=5):',
                        'explanation': 'Default parameters must come after non-default parameters',
                        'difficulty': 'easy',
                        'concepts': ['functions', 'default_parameters']
                    }
                ],
                'data_structures': [
                    {
                        'question': 'What is the time complexity of accessing an element in a Python dictionary?',
                        'options': ['O(1) average case', 'O(log n)', 'O(n)', 'O(n²)'],
                        'answer': 'O(1) average case',
                        'explanation': 'Python dictionaries use hash tables, providing O(1) average case access time',
                        'difficulty': 'medium',
                        'concepts': ['dictionaries', 'time_complexity', 'hash_tables']
                    },
                    {
                        'question': 'Which data structure would be most efficient for implementing a LIFO (Last In, First Out) system?',
                        'options': ['list (using append/pop)', 'deque', 'set', 'tuple'],
                        'answer': 'list (using append/pop)',
                        'explanation': 'Lists with append() and pop() operations provide O(1) LIFO functionality',
                        'difficulty': 'easy',
                        'concepts': ['stacks', 'data_structures', 'algorithms']
                    }
                ],
                'oop': [
                    {
                        'question': 'What is the purpose of the __init__ method in Python classes?',
                        'options': ['To initialize class attributes', 'To create the class', 'To destroy objects', 'To define methods'],
                        'answer': 'To initialize class attributes',
                        'explanation': '__init__ is called when an object is created to initialize its attributes',
                        'difficulty': 'easy',
                        'concepts': ['classes', 'constructors', 'oop']
                    },
                    {
                        'question': 'Which principle allows a child class to override methods of its parent class?',
                        'options': ['Polymorphism', 'Encapsulation', 'Abstraction', 'Composition'],
                        'answer': 'Polymorphism',
                        'explanation': 'Polymorphism allows objects of different classes to be treated uniformly',
                        'difficulty': 'medium',
                        'concepts': ['polymorphism', 'inheritance', 'oop']
                    }
                ],
                'algorithms': [
                    {
                        'question': 'What is the average time complexity of the QuickSort algorithm?',
                        'options': ['O(n log n)', 'O(n²)', 'O(log n)', 'O(n)'],
                        'answer': 'O(n log n)',
                        'explanation': 'QuickSort has O(n log n) average case complexity, O(n²) worst case',
                        'difficulty': 'hard',
                        'concepts': ['sorting', 'algorithms', 'time_complexity']
                    }
                ]
            },
            'java': {
                'syntax': [
                    {
                        'question': 'Which keyword is used to prevent a class from being inherited?',
                        'options': ['final', 'static', 'private', 'abstract'],
                        'answer': 'final',
                        'explanation': 'The final keyword prevents class inheritance when applied to a class',
                        'difficulty': 'medium',
                        'concepts': ['inheritance', 'modifiers', 'final']
                    },
                    {
                        'question': 'What is the correct way to declare a constant in Java?',
                        'options': ['public static final int MAX = 100;', 'const int MAX = 100;', 'final static int MAX = 100;', 'static int MAX = 100;'],
                        'answer': 'public static final int MAX = 100;',
                        'explanation': 'Constants in Java are typically public static final',
                        'difficulty': 'easy',
                        'concepts': ['constants', 'modifiers', 'static']
                    }
                ],
                'oop': [
                    {
                        'question': 'What is the difference between abstract classes and interfaces in Java?',
                        'options': ['Abstract classes can have constructors', 'Interfaces can have constructors', 'No difference', 'Abstract classes cannot have methods'],
                        'answer': 'Abstract classes can have constructors',
                        'explanation': 'Abstract classes can have constructors, instance variables, and concrete methods',
                        'difficulty': 'hard',
                        'concepts': ['abstract_classes', 'interfaces', 'oop']
                    },
                    {
                        'question': 'Which collection interface allows duplicate elements in Java?',
                        'options': ['List', 'Set', 'Map', 'Queue only'],
                        'answer': 'List',
                        'explanation': 'List interface allows duplicate elements, Set does not',
                        'difficulty': 'medium',
                        'concepts': ['collections', 'list', 'set']
                    }
                ],
                'memory': [
                    {
                        'question': 'Where are Java objects stored in memory?',
                        'options': ['Heap', 'Stack', 'Method Area', 'PC Register'],
                        'answer': 'Heap',
                        'explanation': 'Java objects are allocated in the heap memory',
                        'difficulty': 'medium',
                        'concepts': ['memory_management', 'heap', 'jvm']
                    }
                ]
            },
            'javascript': {
                'syntax': [
                    {
                        'question': 'What is the difference between let and var in JavaScript?',
                        'options': ['let has block scope, var has function scope', 'var has block scope, let has function scope', 'No difference', 'let is faster'],
                        'answer': 'let has block scope, var has function scope',
                        'explanation': 'let is block-scoped while var is function-scoped',
                        'difficulty': 'medium',
                        'concepts': ['scope', 'variables', 'es6']
                    },
                    {
                        'question': 'Which operator performs strict equality comparison?',
                        'options': ['===', '==', '=', '!='],
                        'answer': '===',
                        'explanation': '=== compares both value and type without type coercion',
                        'difficulty': 'easy',
                        'concepts': ['operators', 'comparison', 'type_coercion']
                    }
                ],
                'async': [
                    {
                        'question': 'What is the purpose of async/await in JavaScript?',
                        'options': ['To handle asynchronous operations more cleanly', 'To make code run faster', 'To create loops', 'To handle errors'],
                        'answer': 'To handle asynchronous operations more cleanly',
                        'explanation': 'async/await provides a cleaner syntax for handling Promises',
                        'difficulty': 'medium',
                        'concepts': ['async_await', 'promises', 'asynchronous']
                    },
                    {
                        'question': 'What is the execution order: console.log(1); setTimeout(() => console.log(2), 0); console.log(3);',
                        'options': ['1, 3, 2', '1, 2, 3', '3, 1, 2', '2, 1, 3'],
                        'answer': '1, 3, 2',
                        'explanation': 'setTimeout is asynchronous and runs after synchronous code completes',
                        'difficulty': 'hard',
                        'concepts': ['event_loop', 'asynchronous', 'setTimeout']
                    }
                ],
                'functions': [
                    {
                        'question': 'What is a closure in JavaScript?',
                        'options': ['A function with access to outer scope variables', 'A closed function', 'A private function', 'A recursive function'],
                        'answer': 'A function with access to outer scope variables',
                        'explanation': 'Closures allow functions to access variables from their lexical scope',
                        'difficulty': 'hard',
                        'concepts': ['closures', 'scope', 'functions']
                    }
                ]
            },
            'c': {
                'syntax': [
                    {
                        'question': 'Which header file is required for printf() function?',
                        'options': ['<stdio.h>', '<stdlib.h>', '<string.h>', '<math.h>'],
                        'answer': '<stdio.h>',
                        'explanation': 'stdio.h contains declarations for standard I/O functions',
                        'difficulty': 'easy',
                        'concepts': ['headers', 'stdio', 'printf']
                    },
                    {
                        'question': 'What is the correct syntax for declaring a pointer to an integer?',
                        'options': ['int *ptr;', 'int ptr*;', '*int ptr;', 'pointer int ptr;'],
                        'answer': 'int *ptr;',
                        'explanation': 'The asterisk (*) indicates a pointer declaration',
                        'difficulty': 'easy',
                        'concepts': ['pointers', 'declarations', 'syntax']
                    }
                ],
                'memory': [
                    {
                        'question': 'Which function is used for dynamic memory allocation in C?',
                        'options': ['malloc()', 'alloc()', 'new()', 'create()'],
                        'answer': 'malloc()',
                        'explanation': 'malloc() allocates memory dynamically from the heap',
                        'difficulty': 'medium',
                        'concepts': ['memory_allocation', 'malloc', 'heap']
                    },
                    {
                        'question': 'What is the difference between malloc() and calloc()?',
                        'options': ['malloc() doesn\'t initialize, calloc() initializes to zero', 'No difference', 'calloc() is faster', 'malloc() is newer'],
                        'answer': 'malloc() doesn\'t initialize, calloc() initializes to zero',
                        'explanation': 'calloc() initializes allocated memory to zero, malloc() does not',
                        'difficulty': 'medium',
                        'concepts': ['malloc', 'calloc', 'memory_initialization']
                    }
                ],
                'pointers': [
                    {
                        'question': 'What does the & operator do in C?',
                        'options': ['Returns address of variable', 'Performs bitwise AND', 'Creates reference', 'Allocates memory'],
                        'answer': 'Returns address of variable',
                        'explanation': 'The & operator returns the memory address of a variable',
                        'difficulty': 'easy',
                        'concepts': ['address_operator', 'pointers', 'memory']
                    }
                ]
            }
        }
        
        self.difficulty_weights = {'easy': 0.4, 'medium': 0.4, 'hard': 0.2}
        self.used_questions = set()
        
    def generate_unique_questions(self, language: str, num_questions: int = 15) -> List[Dict[str, Any]]:
        """Generate unique questions for a specific programming language"""
        language = language.lower()
        
        if language not in self.question_database:
            return self._generate_fallback_questions(language, num_questions)
        
        # Get all questions for the language
        all_questions = []
        lang_data = self.question_database[language]
        
        for category, questions in lang_data.items():
            for q in questions:
                q_copy = q.copy()
                q_copy['category'] = category
                all_questions.append(q_copy)
        
        # Shuffle and select unique questions
        random.shuffle(all_questions)
        selected_questions = []
        
        # Distribute by difficulty
        easy_target = int(num_questions * self.difficulty_weights['easy'])
        medium_target = int(num_questions * self.difficulty_weights['medium'])
        hard_target = num_questions - easy_target - medium_target
        
        easy_questions = [q for q in all_questions if q['difficulty'] == 'easy']
        medium_questions = [q for q in all_questions if q['difficulty'] == 'medium']
        hard_questions = [q for q in all_questions if q['difficulty'] == 'hard']
        
        # Select questions by difficulty
        selected_questions.extend(easy_questions[:easy_target])
        selected_questions.extend(medium_questions[:medium_target])
        selected_questions.extend(hard_questions[:hard_target])
        
        # Fill remaining with any available questions
        remaining = num_questions - len(selected_questions)
        if remaining > 0:
            available = [q for q in all_questions if q not in selected_questions]
            selected_questions.extend(available[:remaining])
        
        # Shuffle final order
        random.shuffle(selected_questions)
        
        return selected_questions[:num_questions]
    
    def _generate_fallback_questions(self, language: str, num_questions: int) -> List[Dict[str, Any]]:
        """Generate fallback questions if language not supported"""
        fallback = []
        for i in range(num_questions):
            fallback.append({
                'question': f'What is an important concept in {language.title()} programming?',
                'options': [
                    f'{language.title()} concept A',
                    f'{language.title()} concept B', 
                    f'{language.title()} concept C',
                    f'{language.title()} concept D'
                ],
                'answer': f'{language.title()} concept A',
                'explanation': f'This is a general question about {language.title()}',
                'difficulty': 'medium',
                'concepts': ['general'],
                'category': 'general'
            })
        return fallback
    
    def validate_question_uniqueness(self, questions: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Ensure all questions are unique"""
        unique_questions = []
        seen_hashes = set()
        
        for q in questions:
            question_hash = hashlib.md5(q['question'].encode()).hexdigest()
            if question_hash not in seen_hashes:
                seen_hashes.add(question_hash)
                unique_questions.append(q)
        
        return unique_questions
    
    def get_question_statistics(self, questions: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Get statistics about generated questions"""
        stats = {
            'total': len(questions),
            'by_difficulty': {'easy': 0, 'medium': 0, 'hard': 0},
            'by_category': {},
            'unique_concepts': set()
        }
        
        for q in questions:
            # Count by difficulty
            diff = q.get('difficulty', 'medium')
            stats['by_difficulty'][diff] += 1
            
            # Count by category
            cat = q.get('category', 'general')
            stats['by_category'][cat] = stats['by_category'].get(cat, 0) + 1
            
            # Collect concepts
            concepts = q.get('concepts', [])
            stats['unique_concepts'].update(concepts)
        
        stats['unique_concepts'] = list(stats['unique_concepts'])
        return stats

def generate_questions_ml_model(language: str, num_questions: int = 15, mode: str = 'normal') -> List[Dict[str, Any]]:
    """Main function to generate ML-based questions"""
    generator = MLQuestionGenerator()
    
    if mode == 'interview':
        # For interview mode, return open-ended questions
        return [{
            'question': f'Explain a challenging {language} project you worked on and the technical decisions you made.',
            'difficulty': 'interview',
            'category': 'experience',
            'concepts': ['practical_experience', 'problem_solving']
        } for _ in range(min(num_questions, 10))]
    
    # Generate unique MCQ questions
    questions = generator.generate_unique_questions(language, num_questions)
    questions = generator.validate_question_uniqueness(questions)
    
    # Log statistics
    stats = generator.get_question_statistics(questions)
    print(f"Generated {stats['total']} questions for {language}:")
    print(f"Difficulty distribution: {stats['by_difficulty']}")
    print(f"Category distribution: {stats['by_category']}")
    
    return questions

if __name__ == "__main__":
    # Test the generator
    for lang in ['python', 'java', 'javascript', 'c']:
        print(f"\n=== Testing {lang.upper()} ===")
        questions = generate_questions_ml_model(lang, 10)
        for i, q in enumerate(questions[:3]):
            print(f"{i+1}. {q['question']}")
            print(f"   Answer: {q['answer']} (Difficulty: {q['difficulty']})")