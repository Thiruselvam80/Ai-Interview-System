import requests
import json

def test_ml_question_generation():
    print("🧪 Testing ML-Based Question Generation System")
    print("=" * 50)
    
    languages = ['python', 'java', 'javascript', 'c']
    
    for lang in languages:
        print(f"\n📚 Testing {lang.upper()} Questions:")
        try:
            response = requests.post('http://127.0.0.1:5000/generate-questions', 
                                   json={'language': lang, 'num_questions': 5, 'use_ml': True})
            
            if response.status_code == 200:
                data = response.json()
                print(f"✅ Status: {data.get('status')}")
                print(f"🤖 Generator: {data.get('generator')}")
                print(f"📊 Total Questions: {data.get('total_generated')}")
                
                print("\n📝 Sample Questions:")
                for i, q in enumerate(data['questions'][:3]):
                    print(f"{i+1}. {q['question'][:70]}...")
                    print(f"   Difficulty: {q['difficulty']} | Category: {q.get('category', 'N/A')}")
                    print(f"   Answer: {q['answer']}")
                    if q.get('explanation'):
                        print(f"   Explanation: {q['explanation'][:50]}...")
                    print()
            else:
                print(f"❌ Error: {response.status_code}")
                
        except Exception as e:
            print(f"❌ Exception: {e}")
    
    print("\n🔍 Testing Question Uniqueness:")
    try:
        # Get multiple sets of questions for the same language
        set1 = requests.post('http://127.0.0.1:5000/generate-questions', 
                           json={'language': 'python', 'num_questions': 10}).json()
        set2 = requests.post('http://127.0.0.1:5000/generate-questions', 
                           json={'language': 'python', 'num_questions': 10}).json()
        
        questions1 = {q['question'] for q in set1['questions']}
        questions2 = {q['question'] for q in set2['questions']}
        
        overlap = questions1.intersection(questions2)
        uniqueness_score = (len(questions1.union(questions2)) / (len(questions1) + len(questions2))) * 100
        
        print(f"📈 Uniqueness Score: {uniqueness_score:.1f}%")
        print(f"🔄 Overlapping Questions: {len(overlap)}")
        
        if uniqueness_score > 80:
            print("✅ High uniqueness achieved!")
        else:
            print("⚠️ Consider improving uniqueness algorithms")
            
    except Exception as e:
        print(f"❌ Uniqueness test failed: {e}")

if __name__ == "__main__":
    test_ml_question_generation()