from flask import Flask, jsonify
import json

app = Flask(__name__)

# Add CORS headers
@app.after_request
def after_request(response):
    response.headers.add('Access-Control-Allow-Origin', '*')
    response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')
    response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS')
    return response

@app.route('/')
def home():
    return jsonify({"message": "Flask API is working!", "status": "success"})

@app.route('/test-questions', methods=['POST'])
def test_questions():
    # Simple test questions
    test_data = {
        "status": "success",
        "generator": "test",
        "language": "python", 
        "total_generated": 2,
        "questions": [
            {
                "question": "What is Python?",
                "options": ["Programming language", "Snake", "Software", "Database"],
                "answer": "Programming language",
                "difficulty": "easy",
                "category": "basics"
            },
            {
                "question": "How do you create a list in Python?",
                "options": ["[]", "{}", "()", "\"\""],
                "answer": "[]",
                "difficulty": "easy",
                "category": "syntax"
            }
        ]
    }
    return jsonify(test_data)

if __name__ == '__main__':
    print("Starting simple Flask test server...")
    app.run(host='127.0.0.1', port=5001, debug=True)