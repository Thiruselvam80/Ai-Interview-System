// This file contains the main JavaScript logic for the application, including event listeners for user interactions on the home page and course selection.

document.addEventListener('DOMContentLoaded', function() {
    // Event listener for course selection
    const courseLinks = document.querySelectorAll('.course-link');
    courseLinks.forEach(link => {
        link.addEventListener('click', function(event) {
            event.preventDefault();
            const courseId = this.getAttribute('data-course-id');
            // Redirect to the course page or load course content
            window.location.href = `courses.html?courseId=${courseId}`;
        });
    });

    // Event listener for starting the test
    const startTestButton = document.getElementById('start-test');
    if (startTestButton) {
        startTestButton.addEventListener('click', function() {
            window.location.href = 'test.html';
        });
    }
});