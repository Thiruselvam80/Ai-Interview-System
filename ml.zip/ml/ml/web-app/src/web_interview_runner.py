"""
Enhanced Web Interview Runner with Background Integration
Connects the Python backend API with the frontend test interface
"""

import requests
import json
import os
from datetime import datetime

class WebInterviewRunner:
    def __init__(self, api_url='http://127.0.0.1:5000'):
        self.api_url = api_url
        self.current_language = 'Python'
        self.session_data = {
            'start_time': datetime.now().isoformat(),
            'questions_round1': [],
            'questions_round2': [],
            'answers': [],
            'results': {}
        }
    
    def set_language(self, language):
        """Set the programming language for the test"""
        self.current_language = language
        self.session_data['language'] = language
    
    def generate_round1_questions(self):
        """Generate 15 programming questions for round 1"""
        try:
            response = requests.post(
                f'{self.api_url}/generate-questions',
                json={'language': self.current_language}
            )
            if response.status_code == 200:
                self.session_data['questions_round1'] = response.json()['questions']
                return self.session_data['questions_round1']
            else:
                print(f"Error generating Round 1 questions: {response.status_code}")
                return []
        except Exception as e:
            print(f"Connection error: {e}")
            return []
    
    def generate_round2_questions(self):
        """Generate 10 interview questions for round 2"""
        try:
            response = requests.post(
                f'{self.api_url}/generate-interview',
                json={'language': self.current_language}
            )
            if response.status_code == 200:
                self.session_data['questions_round2'] = response.json()['questions']
                return self.session_data['questions_round2']
            else:
                print(f"Error generating Round 2 questions: {response.status_code}")
                return []
        except Exception as e:
            print(f"Connection error: {e}")
            return []
    
    def process_audio_answer(self, audio_file_path):
        """Process audio file and return transcript"""
        try:
            with open(audio_file_path, 'rb') as f:
                files = {'audio': f}
                response = requests.post(f'{self.api_url}/answer-audio', files=files)
                if response.status_code == 200:
                    return response.json()['transcript']
                else:
                    print(f"Error processing audio: {response.status_code}")
                    return ""
        except Exception as e:
            print(f"Audio processing error: {e}")
            return ""
    
    def check_grammar(self, text):
        """Check grammar for given text"""
        try:
            response = requests.post(
                f'{self.api_url}/grammar-check',
                json={'text': text}
            )
            if response.status_code == 200:
                return response.json()
            else:
                print(f"Error checking grammar: {response.status_code}")
                return {}
        except Exception as e:
            print(f"Grammar check error: {e}")
            return {}
    
    def submit_answer(self, question_id, answer_text, is_audio=False):
        """Submit an answer for a question"""
        answer_data = {
            'question_id': question_id,
            'answer': answer_text,
            'timestamp': datetime.now().isoformat(),
            'is_audio': is_audio
        }
        
        # Check grammar if it's a text answer
        if not is_audio and answer_text:
            grammar_result = self.check_grammar(answer_text)
            answer_data['grammar'] = grammar_result
        
        self.session_data['answers'].append(answer_data)
        return answer_data
    
    def generate_final_report(self):
        """Generate the final test report"""
        # Prepare technical results
        technical_results = []
        for answer in self.session_data['answers']:
            technical_results.append({
                'question': answer.get('question_id', ''),
                'answer': answer.get('answer', ''),
                'score': 1,  # Placeholder score
                'timestamp': answer.get('timestamp', '')
            })
        
        # Get grammar summary (use last grammar check or empty)
        grammar_summary = {}
        for answer in reversed(self.session_data['answers']):
            if 'grammar' in answer:
                grammar_summary = answer['grammar']
                break
        
        try:
            response = requests.post(
                f'{self.api_url}/generate-report',
                json={
                    'technical': technical_results,
                    'grammar': grammar_summary,
                    'language': self.current_language,
                    'session': self.session_data
                }
            )
            if response.status_code == 200:
                self.session_data['results'] = response.json()
                return self.session_data['results']
            else:
                print(f"Error generating report: {response.status_code}")
                return {}
        except Exception as e:
            print(f"Report generation error: {e}")
            return {}
    
    def save_session(self, filename=None):
        """Save session data to file"""
        if not filename:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"interview_session_{timestamp}.json"
        
        try:
            with open(filename, 'w') as f:
                json.dump(self.session_data, f, indent=2)
            print(f"Session saved to {filename}")
            return filename
        except Exception as e:
            print(f"Error saving session: {e}")
            return None
    
    def load_session(self, filename):
        """Load session data from file"""
        try:
            with open(filename, 'r') as f:
                self.session_data = json.load(f)
            print(f"Session loaded from {filename}")
            return True
        except Exception as e:
            print(f"Error loading session: {e}")
            return False

# Example usage with web interface integration
def run_web_interview_demo():
    """Demo function showing web interview integration"""
    runner = WebInterviewRunner()
    
    print("🎯 Starting Web Interview Demo")
    print("=" * 50)
    
    # Set language (this could come from the web form)
    language = input("Enter programming language (Java/Python/C): ").strip()
    if language:
        runner.set_language(language)
    
    print(f"\n📚 Generating questions for {runner.current_language}...")
    
    # Generate Round 1 questions
    round1_questions = runner.generate_round1_questions()
    if round1_questions:
        print(f"✅ Generated {len(round1_questions)} Round 1 questions")
        for i, q in enumerate(round1_questions[:3], 1):  # Show first 3
            print(f"   {i}. {q.get('question', 'No question text')}")
    
    # Generate Round 2 questions  
    round2_questions = runner.generate_round2_questions()
    if round2_questions:
        print(f"✅ Generated {len(round2_questions)} Round 2 questions")
        for i, q in enumerate(round2_questions[:2], 1):  # Show first 2
            print(f"   {i}. {q.get('question', 'No question text')}")
    
    # Simulate some answers
    print(f"\n💬 Simulating answers...")
    runner.submit_answer("q1", f"Sample answer for {runner.current_language} programming")
    runner.submit_answer("q2", "This demonstrates object-oriented concepts")
    
    # Generate report
    print(f"\n📊 Generating final report...")
    report = runner.generate_final_report()
    if report:
        print("✅ Report generated successfully")
        print(f"Report preview: {str(report)[:200]}...")
    
    # Save session
    session_file = runner.save_session()
    if session_file:
        print(f"💾 Session saved to {session_file}")
    
    print("\n🏁 Demo completed!")

if __name__ == "__main__":
    run_web_interview_demo()