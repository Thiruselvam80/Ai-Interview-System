#!/usr/bin/env python3
"""
ML Web Application Compiler
Comprehensive compilation and deployment script for the ML-powered interview application
"""

import os
import sys
import subprocess
import json
import time
import requests
from pathlib import Path

class MLWebAppCompiler:
    def __init__(self):
        self.root_dir = Path("d:/ml/ml/web-app")
        self.src_dir = self.root_dir / "src"
        self.public_dir = self.root_dir / "public"
        self.processes = []
        
    def print_header(self, title):
        print("\n" + "="*60)
        print(f"🚀 {title}")
        print("="*60)
    
    def print_step(self, step):
        print(f"\n📋 {step}")
    
    def print_success(self, message):
        print(f"✅ {message}")
    
    def print_error(self, message):
        print(f"❌ {message}")
    
    def print_warning(self, message):
        print(f"⚠️ {message}")
    
    def check_dependencies(self):
        self.print_header("CHECKING DEPENDENCIES")
        
        # Check Node.js
        try:
            result = subprocess.run(['node', '--version'], capture_output=True, text=True, check=True)
            self.print_success(f"Node.js version: {result.stdout.strip()}")
        except Exception as e:
            self.print_error(f"Node.js not found: {e}")
            return False
        
        # Check Python
        try:
            result = subprocess.run([sys.executable, '--version'], capture_output=True, text=True, check=True)
            self.print_success(f"Python version: {result.stdout.strip()}")
        except Exception as e:
            self.print_error(f"Python not found: {e}")
            return False
        
        # Check npm
        try:
            result = subprocess.run(['npm', '--version'], capture_output=True, text=True, check=True)
            self.print_success(f"npm version: {result.stdout.strip()}")
        except Exception as e:
            self.print_error(f"npm not found: {e}")
            return False
        
        return True
    
    def install_dependencies(self):
        self.print_header("INSTALLING DEPENDENCIES")
        
        os.chdir(self.root_dir)
        
        # Install Node.js dependencies
        self.print_step("Installing Node.js dependencies...")
        try:
            subprocess.run(['npm', 'install'], check=True)
            self.print_success("Node.js dependencies installed")
        except Exception as e:
            self.print_error(f"Failed to install Node.js dependencies: {e}")
            return False
        
        # Install Python dependencies
        self.print_step("Installing Python dependencies...")
        try:
            subprocess.run([sys.executable, '-m', 'pip', 'install', 'flask', 'flask-cors', 'requests'], check=True)
            self.print_success("Python dependencies installed")
        except Exception as e:
            self.print_error(f"Failed to install Python dependencies: {e}")
            return False
        
        return True
    
    def validate_files(self):
        self.print_header("VALIDATING PROJECT FILES")
        
        required_files = [
            self.root_dir / "server.js",
            self.root_dir / "package.json",
            self.public_dir / "index.html",
            self.public_dir / "test-launcher.html",
            self.public_dir / "test.html",
            self.public_dir / "debug.html",
            self.public_dir / "courses.html",
            self.public_dir / "js" / "test.js",
            self.src_dir / "simple_questions.py"
        ]
        
        missing_files = []
        for file_path in required_files:
            if file_path.exists():
                self.print_success(f"Found: {file_path.name}")
            else:
                missing_files.append(file_path)
                self.print_error(f"Missing: {file_path}")
        
        if missing_files:
            self.print_error(f"Missing {len(missing_files)} required files")
            return False
        
        self.print_success("All required files present")
        return True
    
    def start_servers(self):
        self.print_header("STARTING SERVERS")
        
        os.chdir(self.root_dir)
        
        # Start Node.js server
        self.print_step("Starting Node.js web server...")
        try:
            node_process = subprocess.Popen(
                ['node', 'server.js'],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                cwd=self.root_dir
            )
            self.processes.append(('Node.js Server', node_process))
            time.sleep(3)  # Give server time to start
            
            if node_process.poll() is None:
                self.print_success("Node.js server started on http://localhost:3000")
            else:
                stdout, stderr = node_process.communicate()
                self.print_error(f"Node.js server failed to start: {stderr}")
                return False
                
        except Exception as e:
            self.print_error(f"Failed to start Node.js server: {e}")
            return False
        
        return True
    
    def test_apis(self):
        self.print_header("TESTING API ENDPOINTS")
        
        # Test Node.js server
        self.print_step("Testing Node.js server connection...")
        try:
            response = requests.get("http://localhost:3000", timeout=5)
            if response.status_code == 200:
                self.print_success("Node.js server responding")
            else:
                self.print_warning(f"Node.js server returned status {response.status_code}")
        except Exception as e:
            self.print_error(f"Node.js server connection failed: {e}")
            return False
        
        # Test question generation
        self.print_step("Testing question generation API...")
        test_languages = ['python', 'java', 'javascript', 'c']
        
        for language in test_languages:
            try:
                response = requests.post(
                    "http://localhost:3000/api/generate-questions",
                    json={"language": language, "num_questions": 3},
                    timeout=10
                )
                if response.status_code == 200:
                    data = response.json()
                    if 'questions' in data and len(data['questions']) > 0:
                        self.print_success(f"{language.capitalize()}: {len(data['questions'])} questions generated")
                    else:
                        self.print_error(f"{language.capitalize()}: No questions in response")
                        return False
                else:
                    self.print_error(f"{language.capitalize()}: API returned status {response.status_code}")
                    return False
            except Exception as e:
                self.print_error(f"{language.capitalize()}: API test failed: {e}")
                return False
        
        return True
    
    def generate_deployment_report(self):
        self.print_header("DEPLOYMENT REPORT")
        
        report = {
            "status": "success",
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
            "services": {
                "node_server": {
                    "url": "http://localhost:3000",
                    "status": "running"
                }
            },
            "endpoints": {
                "main_app": "http://localhost:3000/",
                "test_launcher": "http://localhost:3000/test-launcher.html",
                "debug_console": "http://localhost:3000/debug.html",
                "courses": "http://localhost:3000/courses.html",
                "direct_test": "http://localhost:3000/test.html"
            },
            "features": {
                "question_generation": "✅ Active",
                "4_programming_languages": "✅ Python, Java, JavaScript, C",
                "professional_ui": "✅ Dark theme with animations",
                "debug_console": "✅ API testing interface",
                "course_selection": "✅ 4 courses available",
                "responsive_design": "✅ Mobile and desktop ready"
            },
            "api_tests": {
                "python_questions": "✅ Passed",
                "java_questions": "✅ Passed", 
                "javascript_questions": "✅ Passed",
                "c_questions": "✅ Passed"
            }
        }
        
        # Save report
        report_file = self.root_dir / "deployment_report.json"
        with open(report_file, 'w') as f:
            json.dump(report, f, indent=2)
        
        self.print_success(f"Deployment report saved to {report_file}")
        
        # Print summary
        print("\n📊 DEPLOYMENT SUMMARY")
        print("-" * 40)
        print(f"✅ Status: {report['status'].upper()}")
        print(f"🕒 Timestamp: {report['timestamp']}")
        print(f"🌐 Main App: {report['endpoints']['main_app']}")
        print(f"🚀 Test Launcher: {report['endpoints']['test_launcher']}")
        print(f"🔧 Debug Console: {report['endpoints']['debug_console']}")
        print(f"📚 Courses: {report['endpoints']['courses']}")
        
        return report
    
    def cleanup(self):
        self.print_header("CLEANUP")
        
        for name, process in self.processes:
            if process.poll() is None:
                process.terminate()
                self.print_step(f"Terminated {name}")
    
    def run_compilation(self):
        try:
            self.print_header("ML WEB APPLICATION COMPILER")
            print("🎯 Compiling comprehensive ML-powered interview application")
            print("📅 Features: Question generation, Professional UI, Multi-language support")
            
            # Step 1: Check dependencies
            if not self.check_dependencies():
                return False
            
            # Step 2: Install dependencies
            if not self.install_dependencies():
                return False
            
            # Step 3: Validate files
            if not self.validate_files():
                return False
            
            # Step 4: Start servers
            if not self.start_servers():
                return False
            
            # Step 5: Test APIs
            if not self.test_apis():
                return False
            
            # Step 6: Generate report
            report = self.generate_deployment_report()
            
            self.print_header("🎉 COMPILATION SUCCESSFUL!")
            print("\n🚀 Your ML Web Application is now running!")
            print("\n📝 Access Points:")
            print("   • Main Application: http://localhost:3000")
            print("   • Test Launcher: http://localhost:3000/test-launcher.html") 
            print("   • Debug Console: http://localhost:3000/debug.html")
            print("   • Course Selection: http://localhost:3000/courses.html")
            print("\n💡 The server will continue running in the background.")
            print("💡 Press Ctrl+C to stop all services.")
            
            # Keep servers running
            print("\n⏳ Keeping servers alive... (Press Ctrl+C to stop)")
            try:
                while True:
                    time.sleep(60)
                    # Health check every minute
                    try:
                        requests.get("http://localhost:3000", timeout=2)
                    except:
                        self.print_warning("Health check failed, restarting servers...")
                        self.start_servers()
                        
            except KeyboardInterrupt:
                print("\n🛑 Shutdown requested...")
                self.cleanup()
                print("✅ All services stopped cleanly.")
            
            return True
            
        except Exception as e:
            self.print_error(f"Compilation failed: {e}")
            self.cleanup()
            return False

if __name__ == "__main__":
    compiler = MLWebAppCompiler()
    success = compiler.run_compilation()
    sys.exit(0 if success else 1)