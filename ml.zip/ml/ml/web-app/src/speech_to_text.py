import sys
import json
# Placeholder for speech-to-text
# In production, use Vosk, Google Speech-to-Text, etc.
audio_path = sys.argv[1]
# Dummy transcript
transcript = f"Transcript of {audio_path}"
print(transcript)
