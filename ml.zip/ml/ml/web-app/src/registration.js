import React, { useState } from "react";

const olive = "#556B2F";
const oliveDark = "#3e4d1b";
const oliveLight = "#eaf3e2";

export default function Registration() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    try {
      const res = await fetch("http://localhost:3000/api/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, email }),
      });
      if (res.ok) {
        localStorage.setItem("userName", name);
        localStorage.setItem("userEmail", email);
        window.location.href = "/index.html";
      } else {
        setError("Registration failed. Try again.");
      }
    } catch {
      setError("Network error. Try again.");
    }
    setLoading(false);
  };

  return (
    <div style={{
      minHeight: "100vh",
      background: oliveLight,
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    }}>
      <div style={{
        maxWidth: 400,
        width: "100%",
        background: "#fff",
        borderRadius: 16,
        boxShadow: "0 4px 24px rgba(85,107,47,0.13)",
        padding: "2.5em 2em",
        textAlign: "center",
        border: `2px solid ${olive}`
      }}>
        <p style={{
          color: olive,
          fontWeight: "bold",
          fontSize: "1.3em",
          marginBottom: "0.5em"
        }}>Welcome to SkillUp</p>
        <h2 style={{
          color: oliveDark,
          marginBottom: "1em",
          fontWeight: "bold"
        }}>Register to Continue</h2>
        <form onSubmit={handleSubmit}>
          <input
            type="text"
            placeholder="Your Name"
            required
            value={name}
            onChange={e => setName(e.target.value)}
            style={{
              width: "90%",
              padding: "0.7em",
              margin: "0.7em 0",
              borderRadius: 6,
              border: `1px solid ${olive}`,
              fontSize: "1em",
              background: oliveLight
            }}
          /><br />
          <input
            type="email"
            placeholder="Your Email"
            required
            value={email}
            onChange={e => setEmail(e.target.value)}
            style={{
              width: "90%",
              padding: "0.7em",
              margin: "0.7em 0",
              borderRadius: 6,
              border: `1px solid ${olive}`,
              fontSize: "1em",
              background: oliveLight
            }}
          /><br />
          <button
            type="submit"
            disabled={loading}
            style={{
              marginTop: "1.5em",
              background: olive,
              color: "#fff",
              border: "none",
              borderRadius: 6,
              padding: "0.75em 2em",
              fontSize: "1.1em",
              cursor: "pointer",
              transition: "background 0.2s"
            }}
            onMouseOver={e => e.target.style.background = oliveDark}
            onMouseOut={e => e.target.style.background = olive}
          >
            {loading ? "Registering..." : "Register"}
          </button>
        </form>
        {error && <div style={{ color: "red", marginTop: "1em" }}>{error}</div>}
      </div>
    </div>
  );
}