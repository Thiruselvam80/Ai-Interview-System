const fetch = require('node-fetch');

async function testAPI() {
    try {
        console.log('Testing API...');
        const response = await fetch('http://localhost:3000/api/generate-questions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                language: 'python',
                num_questions: 3
            })
        });

        const data = await response.json();
        console.log('Response:', JSON.stringify(data, null, 2));
        console.log('Status:', response.status);
    } catch (error) {
        console.error('Error:', error);
    }
}

testAPI();