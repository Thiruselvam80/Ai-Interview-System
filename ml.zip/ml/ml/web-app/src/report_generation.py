
import json

def generate_report_model(technical, grammar):
    technical_score = sum([q.get('score', 1) for q in technical]) if technical else 0
    grammar_score = grammar.get('score', 0) if grammar else 0
    improvement = []
    if technical_score < 10:
        improvement.append('Improve technical answers')
    if grammar_score < 90:
        improvement.append('Work on grammar')
    return {
        'technical_score': technical_score,
        'grammar_score': grammar_score,
        'improvement': improvement
    }
