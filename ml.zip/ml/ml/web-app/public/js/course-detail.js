document.addEventListener('DOMContentLoaded', function() {
    const params = new URLSearchParams(window.location.search);
    const course = params.get('course');
    const title = document.getElementById('course-title');
    const readBtn = document.getElementById('read-course-btn');
    let link = '#';

    if (course === 'java') {
        title.textContent = 'Java';
        link = 'https://www.tutorialspoint.com/java/java_tutorial.pdf';
    } else if (course === 'python') {
        title.textContent = 'Python';
        link = 'https://www.tutorialspoint.com/python/python_tutorial.pdf';
    } else if (course === 'c') {
        title.textContent = 'C';
        link = 'https://www.tutorialspoint.com/cprogramming/index.htm';
    }

    readBtn.onclick = () => window.open(link, '_blank');
});