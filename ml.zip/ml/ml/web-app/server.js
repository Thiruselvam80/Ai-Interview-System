const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const app = express();

// Connect to MongoDB
mongoose.connect('mongodb://127.0.0.1:27017/skillup')
  .then(() => console.log('MongoDB connected'))
  .catch(err => {
    console.error('MongoDB connection failed:', err.message);
    console.log('Continuing without MongoDB...');
  });


// Middleware
app.use(cors());
app.use(express.json());

// Serve static files
app.use(express.static(__dirname + '/public'));

// Serve index.html at root
app.get('/', (req, res) => {
  res.sendFile(__dirname + '/public/index.html');
});

// Schema and model
const User = mongoose.model('User', new mongoose.Schema({
  name: String,
  email: String
}));

// API endpoint
app.post('/api/register', async (req, res) => {
  const { name, email } = req.body;
  try {
    const user = new User({ name, email });
    await user.save();
    res.status(201).json({ message: 'User registered successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Registration failed' });
  }
});

// Start server

// ML and Speech-to-Text dependencies
const { spawn } = require('child_process');
const multer = require('multer');
const upload = multer({ dest: 'uploads/' });

// Test endpoint
app.get('/api/test', (req, res) => {
  console.log('🔥 Test endpoint hit!');
  res.json({ message: 'API is working!', timestamp: new Date().toISOString() });
});

// Endpoint: Generate questions for round 1 (15 questions, easy/medium/hard)
app.post('/api/generate-questions', async (req, res) => {
  console.log('🔥 API Request received:', req.body);
  console.log('🔥 Request headers:', req.headers);
  const { language, num_questions = 15 } = req.body;
  console.log(`Generating ${num_questions} questions for ${language}`);
  
  try {
    // Extended question bank for each language
    const questionBank = {
      python: [
        { question: 'What is Python?', options: ['Programming language', 'Snake', 'Software', 'Database'], answer: 'Programming language' },
        { question: 'How do you create a list in Python?', options: ['[]', '{}', '()', '""'], answer: '[]' },
        { question: 'What keyword defines a function in Python?', options: ['def', 'function', 'fun', 'define'], answer: 'def' },
        { question: 'Which operator is used for exponentiation in Python?', options: ['**', '^', 'exp', 'pow'], answer: '**' },
        { question: 'What is the correct syntax for a comment in Python?', options: ['# comment', '// comment', '/* comment */', '<!-- comment -->'], answer: '# comment' },
        { question: 'How do you create a dictionary in Python?', options: ['{}', '[]', '()', 'dict()'], answer: '{}' },
        { question: 'What is the output of len("Python")?', options: ['6', '5', '7', 'Error'], answer: '6' },
        { question: 'Which method adds an element to the end of a list?', options: ['append()', 'add()', 'insert()', 'push()'], answer: 'append()' },
        { question: 'What does the range(3) function return?', options: ['[0, 1, 2]', '[1, 2, 3]', '3', 'Error'], answer: '[0, 1, 2]' },
        { question: 'How do you import a module in Python?', options: ['import module', 'include module', 'require module', 'using module'], answer: 'import module' },
        { question: 'What is the correct way to create a tuple?', options: ['(1, 2, 3)', '[1, 2, 3]', '{1, 2, 3}', '1, 2, 3'], answer: '(1, 2, 3)' },
        { question: 'Which keyword is used for exception handling?', options: ['try', 'catch', 'except', 'handle'], answer: 'try' },
        { question: 'What is the output of 3 // 2 in Python?', options: ['1', '1.5', '2', 'Error'], answer: '1' },
        { question: 'How do you create a class in Python?', options: ['class MyClass:', 'class MyClass()', 'def MyClass:', 'create MyClass:'], answer: 'class MyClass:' },
        { question: 'What is Python\'s built-in function to get user input?', options: ['input()', 'get()', 'read()', 'scan()'], answer: 'input()' },
        { question: 'Which data type is mutable in Python?', options: ['list', 'tuple', 'string', 'int'], answer: 'list' },
        { question: 'What does the "pass" statement do?', options: ['Does nothing', 'Ends program', 'Skips loop', 'Returns value'], answer: 'Does nothing' },
        { question: 'How do you check the type of a variable?', options: ['type(var)', 'typeof(var)', 'var.type()', 'check(var)'], answer: 'type(var)' },
        { question: 'What is the correct way to open a file?', options: ['open("file.txt")', 'file("file.txt")', 'read("file.txt")', 'load("file.txt")'], answer: 'open("file.txt")' },
        { question: 'Which operator is used for string concatenation?', options: ['+', '&', '.', '++'], answer: '+' }
      ],
      java: [
        { question: 'What is Java?', options: ['Programming language', 'Coffee', 'Operating system', 'Database'], answer: 'Programming language' },
        { question: 'Which keyword is used to define a class in Java?', options: ['class', 'Class', 'define', 'object'], answer: 'class' },
        { question: 'What is the entry point of a Java application?', options: ['main() method', 'start() method', 'run() method', 'init() method'], answer: 'main() method' },
        { question: 'Which access modifier makes a member accessible everywhere?', options: ['public', 'private', 'protected', 'default'], answer: 'public' },
        { question: 'What is used to create an object in Java?', options: ['new keyword', 'create keyword', 'object keyword', 'make keyword'], answer: 'new keyword' },
        { question: 'Which keyword is used for inheritance in Java?', options: ['extends', 'inherits', 'implements', 'super'], answer: 'extends' },
        { question: 'What is the correct syntax for a Java array?', options: ['int[] arr', 'int arr[]', 'Both A and B', 'array int arr'], answer: 'Both A and B' },
        { question: 'Which collection class allows duplicate elements?', options: ['ArrayList', 'HashSet', 'TreeSet', 'LinkedHashSet'], answer: 'ArrayList' },
        { question: 'What is the default value of a boolean in Java?', options: ['false', 'true', '0', 'null'], answer: 'false' },
        { question: 'Which keyword is used to prevent inheritance?', options: ['final', 'static', 'abstract', 'private'], answer: 'final' },
        { question: 'What is the correct way to declare a constant?', options: ['final int MAX = 100', 'const int MAX = 100', 'static int MAX = 100', 'readonly int MAX = 100'], answer: 'final int MAX = 100' },
        { question: 'Which method is called when an object is created?', options: ['constructor', 'init()', 'create()', 'new()'], answer: 'constructor' },
        { question: 'What is the superclass of all classes in Java?', options: ['Object', 'Class', 'Super', 'Base'], answer: 'Object' },
        { question: 'Which keyword is used for multiple inheritance of interfaces?', options: ['implements', 'extends', 'inherits', 'uses'], answer: 'implements' },
        { question: 'What is the correct way to handle exceptions?', options: ['try-catch', 'try-except', 'catch-throw', 'handle-error'], answer: 'try-catch' },
        { question: 'Which loop is guaranteed to execute at least once?', options: ['do-while', 'while', 'for', 'foreach'], answer: 'do-while' },
        { question: 'What is the correct way to compare strings?', options: ['str1.equals(str2)', 'str1 == str2', 'str1.compare(str2)', 'compare(str1, str2)'], answer: 'str1.equals(str2)' },
        { question: 'Which keyword is used to refer to the current object?', options: ['this', 'self', 'current', 'me'], answer: 'this' },
        { question: 'What is the correct syntax for a package declaration?', options: ['package com.example;', 'import com.example;', 'namespace com.example;', 'using com.example;'], answer: 'package com.example;' },
        { question: 'Which collection maintains insertion order?', options: ['LinkedHashMap', 'HashMap', 'TreeMap', 'HashTable'], answer: 'LinkedHashMap' }
      ],
      javascript: [
        { question: 'What is JavaScript?', options: ['Programming language', 'Java variant', 'Coffee script', 'Database'], answer: 'Programming language' },
        { question: 'How do you declare a variable in modern JavaScript?', options: ['let', 'var', 'const', 'All of the above'], answer: 'All of the above' },
        { question: 'What does DOM stand for?', options: ['Document Object Model', 'Data Object Model', 'Dynamic Object Model', 'Direct Object Model'], answer: 'Document Object Model' },
        { question: 'Which method is used to add an element to the end of an array?', options: ['push()', 'add()', 'append()', 'insert()'], answer: 'push()' },
        { question: 'What is the correct way to write a JavaScript function?', options: ['function myFunction()', 'def myFunction()', 'function = myFunction()', 'create myFunction()'], answer: 'function myFunction()' },
        { question: 'How do you create an object in JavaScript?', options: ['{}', '[]', '()', 'object()'], answer: '{}' },
        { question: 'Which operator is used for strict equality?', options: ['===', '==', '=', '!='], answer: '===' },
        { question: 'What is the correct way to write a comment?', options: ['// comment', '# comment', '<!-- comment -->', '/* comment */'], answer: '// comment' },
        { question: 'How do you access an array element?', options: ['arr[0]', 'arr.get(0)', 'arr(0)', 'arr{0}'], answer: 'arr[0]' },
        { question: 'Which method removes the last element from an array?', options: ['pop()', 'remove()', 'delete()', 'splice()'], answer: 'pop()' },
        { question: 'What is the correct syntax for an arrow function?', options: ['() => {}', '() -> {}', '() : {}', '() | {}'], answer: '() => {}' },
        { question: 'How do you check if a variable is undefined?', options: ['typeof var === "undefined"', 'var === undefined', 'Both A and B', 'var.isUndefined()'], answer: 'Both A and B' },
        { question: 'Which method is used to iterate over an array?', options: ['forEach()', 'iterate()', 'loop()', 'each()'], answer: 'forEach()' },
        { question: 'What is the correct way to create a Promise?', options: ['new Promise()', 'Promise.create()', 'Promise.new()', 'createPromise()'], answer: 'new Promise()' },
        { question: 'How do you convert a string to a number?', options: ['parseInt()', 'Number()', '+str', 'All of the above'], answer: 'All of the above' },
        { question: 'Which keyword is used to handle asynchronous operations?', options: ['async', 'await', 'Both A and B', 'promise'], answer: 'Both A and B' },
        { question: 'What is the correct way to select an element by ID?', options: ['getElementById()', 'selectById()', 'querySelector()', 'findById()'], answer: 'getElementById()' },
        { question: 'How do you add an event listener?', options: ['addEventListener()', 'addEvent()', 'on()', 'listen()'], answer: 'addEventListener()' },
        { question: 'What is the difference between let and var?', options: ['Block scope vs Function scope', 'No difference', 'let is faster', 'var is newer'], answer: 'Block scope vs Function scope' },
        { question: 'Which method is used to join array elements?', options: ['join()', 'concat()', 'merge()', 'combine()'], answer: 'join()' }
      ],
      c: [
        { question: 'What is C?', options: ['Programming language', 'Operating system', 'Database', 'Hardware'], answer: 'Programming language' },
        { question: 'Which header file is needed for printf()?', options: ['stdio.h', 'stdlib.h', 'string.h', 'math.h'], answer: 'stdio.h' },
        { question: 'What is the correct syntax to declare a pointer in C?', options: ['int *p', 'int p*', '*int p', 'pointer int p'], answer: 'int *p' },
        { question: 'Which function is used to allocate memory dynamically?', options: ['malloc()', 'alloc()', 'memory()', 'new()'], answer: 'malloc()' },
        { question: 'What does the & operator do in C?', options: ['Address of operator', 'Bitwise AND', 'Logical AND', 'Reference operator'], answer: 'Address of operator' },
        { question: 'How do you free dynamically allocated memory?', options: ['free()', 'delete()', 'remove()', 'clear()'], answer: 'free()' },
        { question: 'What is the size of int on a 32-bit system?', options: ['4 bytes', '2 bytes', '8 bytes', '1 byte'], answer: '4 bytes' },
        { question: 'Which loop is entry-controlled?', options: ['while', 'do-while', 'Both A and B', 'None'], answer: 'while' },
        { question: 'What is the correct way to declare an array?', options: ['int arr[10]', 'array int arr[10]', 'int[10] arr', 'declare int arr[10]'], answer: 'int arr[10]' },
        { question: 'Which operator is used to access structure members?', options: ['.', '->', 'Both A and B', '::'], answer: 'Both A and B' },
        { question: 'What is the return type of main() function?', options: ['int', 'void', 'char', 'float'], answer: 'int' },
        { question: 'Which function is used to read a character?', options: ['getchar()', 'getch()', 'scanf()', 'read()'], answer: 'getchar()' },
        { question: 'What does NULL represent in C?', options: ['Empty pointer', '0', 'Both A and B', 'Undefined'], answer: 'Both A and B' },
        { question: 'Which header file is needed for string functions?', options: ['string.h', 'stdio.h', 'stdlib.h', 'ctype.h'], answer: 'string.h' },
        { question: 'What is the correct syntax for a switch statement?', options: ['switch(var)', 'switch var', 'switch(var):', 'case(var)'], answer: 'switch(var)' },
        { question: 'How do you declare a constant in C?', options: ['const int x = 10', '#define X 10', 'Both A and B', 'constant int x = 10'], answer: 'Both A and B' },
        { question: 'Which function is used to copy strings?', options: ['strcpy()', 'strcat()', 'strcmp()', 'strlen()'], answer: 'strcpy()' },
        { question: 'What is the scope of a local variable?', options: ['Within the function', 'Entire program', 'Within the file', 'Global scope'], answer: 'Within the function' },
        { question: 'How do you pass an array to a function?', options: ['func(arr)', 'func(&arr)', 'func(*arr)', 'func(arr[])'], answer: 'func(arr)' },
        { question: 'Which preprocessor directive includes header files?', options: ['#include', '#define', '#ifdef', '#pragma'], answer: '#include' }
      ]
    };
    
    const allQuestions = questionBank[language.toLowerCase()] || questionBank.python;
    
    // Shuffle and select random questions
    const shuffled = allQuestions.sort(() => Math.random() - 0.5);
    const questions = shuffled.slice(0, Math.min(num_questions, allQuestions.length));
    
    console.log(`✅ Successfully generated ${questions.length} random questions for ${language}`);
    res.json({ questions, status: 'success', total: questions.length, generator: 'random' });
  } catch (error) {
    console.error('❌ Error generating questions:', error);
    res.status(500).json({ error: 'Internal server error', message: error.message });
  }
});

// Endpoint: Generate mock interview questions for round 2 (10 questions)
app.post('/api/generate-interview', async (req, res) => {
  const { language } = req.body;
  const py = spawn('python', ['../src/question_generation.py', language, '10', 'interview']);
  let data = '';
  py.stdout.on('data', chunk => { data += chunk; });
  py.on('close', code => {
    if (code === 0) {
      try {
        const questions = JSON.parse(data);
        res.json({ questions });
      } catch (e) {
        res.status(500).json({ error: 'Failed to parse interview questions' });
      }
    } else {
      res.status(500).json({ error: 'Interview question generation failed' });
    }
  });
});

// Endpoint: Receive audio answer, convert to text (speech-to-text)
app.post('/api/answer-audio', upload.single('audio'), async (req, res) => {
  const audioPath = req.file.path;
  // Call Python script for speech-to-text (or use API)
  const py = spawn('python', ['../src/speech_to_text.py', audioPath]);
  let data = '';
  py.stdout.on('data', chunk => { data += chunk; });
  py.on('close', code => {
    if (code === 0) {
      res.json({ transcript: data.trim() });
    } else {
      res.status(500).json({ error: 'Speech-to-text failed' });
    }
  });
});

// Enhanced Grammar detection endpoint with proper analysis
app.post('/api/grammar-check', async (req, res) => {
  const { text } = req.body;
  console.log('Grammar check requested for text:', text);
  
  try {
    // Implement basic grammar analysis
    const grammarAnalysis = analyzeGrammar(text);
    res.json(grammarAnalysis);
  } catch (error) {
    console.error('Grammar check error:', error);
    res.status(500).json({ 
      error: 'Grammar detection failed',
      score: 0,
      issues: ['Grammar analysis service error'],
      status: 'error'
    });
  }
});

// Function to analyze grammar (basic implementation)
function analyzeGrammar(text) {
  if (!text || text.trim() === '') {
    return {
      score: 0,
      issues: ['No text provided'],
      status: 'error',
      feedback: 'No content to analyze'
    };
  }

  if (text === 'SKIPPED') {
    return {
      score: 0,
      issues: ['Question was skipped'],
      status: 'skipped',
      feedback: 'No evaluation - question skipped'
    };
  }

  const issues = [];
  let score = 100; // Start with perfect score
  
  // Basic grammar checks
  const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 0);
  const words = text.split(/\s+/).filter(w => w.length > 0);
  
  // Check for basic issues
  if (words.length < 3) {
    issues.push('Response too short for proper analysis');
    score -= 20;
  }
  
  // Check capitalization
  if (!/^[A-Z]/.test(text.trim())) {
    issues.push('Should start with capital letter');
    score -= 10;
  }
  
  // Check ending punctuation
  if (!/[.!?]$/.test(text.trim())) {
    issues.push('Missing ending punctuation');
    score -= 10;
  }
  
  // Check for common grammar issues
  const commonErrors = [
    { pattern: /\bi\s/gi, correct: 'I should be capitalized', deduction: 5 },
    { pattern: /\s{2,}/g, correct: 'Multiple spaces detected', deduction: 5 },
    { pattern: /[,.](\w)/g, correct: 'Missing space after punctuation', deduction: 5 },
    { pattern: /(\w)[,.](\w)/g, correct: 'Punctuation spacing issue', deduction: 3 }
  ];
  
  commonErrors.forEach(error => {
    if (error.pattern.test(text)) {
      issues.push(error.correct);
      score -= error.deduction;
    }
  });
  
  // Check sentence structure
  sentences.forEach((sentence, idx) => {
    const sentenceWords = sentence.trim().split(/\s+/);
    if (sentenceWords.length < 2) {
      issues.push(`Sentence ${idx + 1}: Too short or incomplete`);
      score -= 8;
    }
  });
  
  // Ensure score doesn't go below 0
  score = Math.max(0, score);
  
  // Determine feedback based on score
  let feedback = '';
  if (score >= 90) {
    feedback = 'Excellent grammar and structure';
  } else if (score >= 75) {
    feedback = 'Good grammar with minor issues';
  } else if (score >= 60) {
    feedback = 'Fair grammar, some improvement needed';
  } else if (score >= 40) {
    feedback = 'Grammar needs significant improvement';
  } else {
    feedback = 'Poor grammar, major revision required';
  }
  
  return {
    score: score,
    issues: issues,
    status: 'analyzed',
    feedback: feedback,
    wordCount: words.length,
    sentenceCount: sentences.length,
    analysis: {
      hasCapitalStart: /^[A-Z]/.test(text.trim()),
      hasEndPunctuation: /[.!?]$/.test(text.trim()),
      avgWordsPerSentence: sentences.length > 0 ? Math.round(words.length / sentences.length) : 0
    }
  };
}

// Endpoint: Generate report
app.post('/api/generate-report', async (req, res) => {
  const { technical, grammar } = req.body;
  // Call Python script for report generation
  const py = spawn('python', ['../src/report_generation.py', JSON.stringify(technical), JSON.stringify(grammar)]);
  let data = '';
  py.stdout.on('data', chunk => { data += chunk; });
  py.on('close', code => {
    if (code === 0) {
      try {
        const report = JSON.parse(data);
        res.json(report);
      } catch (e) {
        res.status(500).json({ error: 'Failed to parse report' });
      }
    } else {
      res.status(500).json({ error: 'Report generation failed' });
    }
  });
});

app.listen(3000, () => {
  console.log('Server running on http://localhost:3000');
});
