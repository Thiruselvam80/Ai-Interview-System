#!/bin/bash

# SkillUp Web Application - Quick Start Script
# Run this script to start the complete application

echo "🚀 Starting SkillUp Web Application..."
echo "======================================"

# Navigate to project directory
cd "D:\ml\ml\web-app"

# Check if server.js exists
if [ ! -f "server.js" ]; then
    echo "❌ Error: server.js not found!"
    echo "Please ensure you're in the correct directory."
    exit 1
fi

# Start the server
echo "📡 Starting Node.js server..."
node server.js &
SERVER_PID=$!

# Wait a moment for server to start
sleep 2

echo "✅ Server started successfully!"
echo ""
echo "🌐 Application URLs:"
echo "   Main Entry:      http://localhost:3000/"
echo "   Course Selection: http://localhost:3000/test-launcher.html"
echo "   Debug Console:    http://localhost:3000/debug.html"
echo ""
echo "📋 Available Features:"
echo "   • 4 Programming Languages (Python, Java, JavaScript, C)"
echo "   • 15 Random Questions per Round 1"
echo "   • Voice-based Interview (Round 2)"
echo "   • Comprehensive Reporting"
echo "   • Debug & Testing Tools"
echo ""
echo "🛑 To stop the server:"
echo "   Press Ctrl+C or run: kill $SERVER_PID"
echo ""
echo "🎉 Application is ready! Open your browser and navigate to the URLs above."

# Keep script running
wait $SERVER_PID