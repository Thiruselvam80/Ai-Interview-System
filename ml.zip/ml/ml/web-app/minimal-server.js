const express = require('express');
const cors = require('cors');
const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(__dirname + '/public'));

// Test endpoint
app.get('/api/test', (req, res) => {
  console.log('✅ Test endpoint hit!');
  res.json({ message: 'API is working!', timestamp: new Date().toISOString() });
});

// Question generation endpoint
app.post('/api/generate-questions', (req, res) => {
  console.log('🔥 Question generation request:', req.body);
  
  const { language = 'python', num_questions = 3 } = req.body;
  
  const questions = [
    {
      question: `What is ${language}?`,
      options: ['Programming language', 'Snake', 'Software', 'Database'],
      answer: 'Programming language'
    },
    {
      question: `How do you create a variable in ${language}?`,
      options: ['var x', 'let x', 'x =', 'define x'],
      answer: 'var x'
    },
    {
      question: `What is a function in ${language}?`,
      options: ['Code block', 'Variable', 'Object', 'Array'],
      answer: 'Code block'
    }
  ];
  
  console.log(`✅ Generated ${questions.length} questions for ${language}`);
  res.json({ questions, status: 'success', total: questions.length });
});

// Start server
app.listen(3000, '127.0.0.1', () => {
  console.log('🚀 Minimal server running on http://127.0.0.1:3000');
});