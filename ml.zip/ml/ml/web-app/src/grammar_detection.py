
import json

def grammar_check_model(text):
    # Dummy grammar check
    return {
        'score': 85,
        'issues': ['Missing comma', 'Incorrect tense'],
        'suggestions': ['Add comma after clause', 'Use present tense']
    }
