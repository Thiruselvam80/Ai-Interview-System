from flask import Flask, request, jsonify
import os
import json
import tempfile
from datetime import datetime

from question_generation import generate_questions_model
from advanced_question_generator import generate_questions_ml_model
from grammar_detection import grammar_check_model
from report_generation import generate_report_model


app = Flask(__name__)

# Add CORS headers to all responses
@app.after_request
def after_request(response):
    response.headers.add('Access-Control-Allow-Origin', '*')
    response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')
    response.headers.add('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE,OPTIONS')
    return response

# Root endpoint for homepage
@app.route('/')
def home():
    return '<h2>Welcome to the ML Interview API! Endpoints: /generate-questions, /generate-interview, /answer-audio, /grammar-check, /generate-report</h2>'

@app.route('/generate-questions', methods=['POST'])
def generate_questions():
    data = request.get_json()
    language = data.get('language', 'python')
    num_questions = data.get('num_questions', 15)
    use_ml = data.get('use_ml', True)  # Use ML model by default
    
    # Validate language
    supported_languages = ['python', 'java', 'c', 'javascript']
    if language.lower() not in supported_languages:
        return jsonify({'error': f'Unsupported language: {language}. Supported: {supported_languages}'}), 400
    
    try:
        # Use the advanced ML-based question generator
        if use_ml:
            print(f"Generating {num_questions} ML-based questions for {language}")
            raw_questions = generate_questions_ml_model(language, num_questions, mode='normal')
        else:
            # Fallback to template-based generator
            raw_questions = generate_questions_model(language, num_questions, mode='normal')
        
        # Format questions for frontend
        formatted_questions = []
        
        for i, q in enumerate(raw_questions):
            # Ensure all required fields are present
            question_data = {
                'question': q.get('question', f'Question {i+1} for {language}'),
                'options': q.get('options', ['Option A', 'Option B', 'Option C', 'Option D']),
                'answer': q.get('answer', q.get('options', ['Option A'])[0]),
                'difficulty': q.get('difficulty', 'medium'),
                'concepts': q.get('concepts', []),
                'category': q.get('category', 'general'),
                'explanation': q.get('explanation', '')
            }
            formatted_questions.append(question_data)
        
        print(f"Successfully generated {len(formatted_questions)} questions")
        
        return jsonify({
            'questions': formatted_questions,
            'language': language,
            'total_generated': len(formatted_questions),
            'status': 'success',
            'generator': 'ml_based' if use_ml else 'template_based',
            'timestamp': str(datetime.now())
        })
        
    except Exception as e:
        print(f"Error generating questions: {str(e)}")
        
        # Emergency fallback questions
        basic_templates = {
            'python': [
                {'q': 'What is the correct way to create a list in Python?', 'opts': ['[]', '{}', '()', '""'], 'ans': '[]'},
                {'q': 'Which keyword defines a function in Python?', 'opts': ['def', 'function', 'define', 'func'], 'ans': 'def'},
                {'q': 'What data type is returned by len()?', 'opts': ['int', 'str', 'float', 'bool'], 'ans': 'int'},
                {'q': 'How do you comment a single line in Python?', 'opts': ['#', '//', '/* */', '--'], 'ans': '#'},
                {'q': 'Which is mutable in Python?', 'opts': ['list', 'tuple', 'string', 'int'], 'ans': 'list'}
            ],
            'java': [
                {'q': 'Which keyword creates a constant in Java?', 'opts': ['final', 'const', 'static', 'var'], 'ans': 'final'},
                {'q': 'Java programs run on which platform?', 'opts': ['JVM', 'CPU', 'OS', 'Browser'], 'ans': 'JVM'},
                {'q': 'Which access modifier is most restrictive?', 'opts': ['private', 'public', 'protected', 'default'], 'ans': 'private'},
                {'q': 'What is the entry point of Java programs?', 'opts': ['main method', 'constructor', 'class', 'package'], 'ans': 'main method'},
                {'q': 'Which keyword is used for inheritance?', 'opts': ['extends', 'inherits', 'implements', 'derives'], 'ans': 'extends'}
            ],
            'javascript': [
                {'q': 'Which operator checks strict equality?', 'opts': ['===', '==', '=', '!='], 'ans': '==='},
                {'q': 'How do you declare a variable with block scope?', 'opts': ['let', 'var', 'const', 'variable'], 'ans': 'let'},
                {'q': 'What is the typeof null in JavaScript?', 'opts': ['object', 'null', 'undefined', 'string'], 'ans': 'object'},
                {'q': 'Which method adds element to end of array?', 'opts': ['push()', 'add()', 'append()', 'insert()'], 'ans': 'push()'},
                {'q': 'What is a closure in JavaScript?', 'opts': ['Function with access to outer scope', 'Closed function', 'Loop', 'Object'], 'ans': 'Function with access to outer scope'}
            ],
            'c': [
                {'q': 'Which header file contains printf()?', 'opts': ['<stdio.h>', '<stdlib.h>', '<string.h>', '<math.h>'], 'ans': '<stdio.h>'},
                {'q': 'How do you declare a pointer in C?', 'opts': ['int *ptr', 'int ptr*', '*int ptr', 'pointer int'], 'ans': 'int *ptr'},
                {'q': 'Which function allocates memory dynamically?', 'opts': ['malloc()', 'alloc()', 'new()', 'create()'], 'ans': 'malloc()'},
                {'q': 'What does & operator do?', 'opts': ['Gets address', 'Logical AND', 'Reference', 'Pointer'], 'ans': 'Gets address'},
                {'q': 'Which loop runs at least once?', 'opts': ['do-while', 'while', 'for', 'none'], 'ans': 'do-while'}
            ]
        }
        
        templates = basic_templates.get(language.lower(), basic_templates['python'])
        emergency_fallback = []
        
        for i in range(num_questions):
            template = templates[i % len(templates)]
            emergency_fallback.append({
                'question': template['q'],
                'options': template['opts'],
                'answer': template['ans'],
                'difficulty': 'easy',
                'concepts': ['basic'],
                'category': 'fundamental'
            })
        
        return jsonify({
            'questions': emergency_fallback,
            'language': language,
            'total_generated': len(emergency_fallback),
            'status': 'emergency_fallback',
            'error': str(e),
            'generator': 'emergency'
        })

@app.route('/generate-interview', methods=['POST'])
def generate_interview():
    data = request.get_json()
    language = data.get('language')
    num_questions = 10
    questions = generate_questions_model(language, num_questions, mode='interview')
    return jsonify({'questions': questions})

@app.route('/answer-audio', methods=['POST'])
def answer_audio():
    if 'audio' not in request.files:
        return jsonify({'error': 'No audio file provided'}), 400
    audio = request.files['audio']
    with tempfile.NamedTemporaryFile(delete=False) as tmp:
        audio.save(tmp.name)
        transcript = speech_to_text_func(tmp.name)
    os.remove(tmp.name)
    return jsonify({'transcript': transcript})

@app.route('/grammar-check', methods=['POST'])
def grammar_check():
    data = request.get_json()
    text = data.get('text')
    result = grammar_check_model(text)
    return jsonify(result)

@app.route('/generate-report', methods=['POST'])
def generate_report():
    data = request.get_json()
    technical = data.get('technical')
    grammar = data.get('grammar')
    report = generate_report_model(technical, grammar)
    return jsonify(report)

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=5000, debug=True)

# --- Helper functions ---
def speech_to_text_func(audio_path):
    # Dummy transcript, replace with real speech-to-text
    return f"Transcript of {audio_path}"
