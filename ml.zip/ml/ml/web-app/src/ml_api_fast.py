from fastapi import FastAPI, UploadFile, File
from fastapi.responses import JSONResponse
from pydantic import BaseModel
import tempfile
import os

app = FastAPI()

class LanguageRequest(BaseModel):
    language: str

class TextRequest(BaseModel):
    text: str

class ReportRequest(BaseModel):
    technical: list
    grammar: dict

@app.post('/generate-questions')
def generate_questions(req: LanguageRequest):
    language = req.language
    num_questions = 15
    questions = generate_questions_func(language, num_questions, mode='normal')
    return JSONResponse({'questions': questions})

@app.post('/generate-interview')
def generate_interview(req: LanguageRequest):
    language = req.language
    num_questions = 10
    questions = generate_questions_func(language, num_questions, mode='interview')
    return JSONResponse({'questions': questions})

@app.post('/answer-audio')
def answer_audio(audio: UploadFile = File(...)):
    with tempfile.NamedTemporaryFile(delete=False) as tmp:
        tmp.write(audio.file.read())
        transcript = speech_to_text_func(tmp.name)
    os.remove(tmp.name)
    return JSONResponse({'transcript': transcript})

@app.post('/grammar-check')
def grammar_check(req: TextRequest):
    result = grammar_detection_func(req.text)
    return JSONResponse(result)

@app.post('/generate-report')
def generate_report(req: ReportRequest):
    report = report_generation_func(req.technical, req.grammar)
    return JSONResponse(report)

# --- Helper functions ---
def generate_questions_func(language, num_questions, mode='normal'):
    questions = []
    if mode == 'normal':
        for i in range(num_questions):
            diff = ['easy', 'medium', 'hard'][i % 3]
            questions.append({
                'question': f'{language} {diff} question {i+1}',
                'difficulty': diff
            })
    else:
        for i in range(num_questions):
            questions.append({
                'question': f'{language} interview question {i+1}',
                'difficulty': 'interview'
            })
    return questions

def speech_to_text_func(audio_path):
    return f"Transcript of {audio_path}"

def grammar_detection_func(text):
    return {
        'score': 85,
        'issues': ['Missing comma', 'Incorrect tense'],
        'suggestions': ['Add comma after clause', 'Use present tense']
    }

def report_generation_func(technical, grammar):
    technical_score = sum([q.get('score', 1) for q in technical]) if technical else 0
    grammar_score = grammar.get('score', 0) if grammar else 0
    improvement = []
    if technical_score < 10:
        improvement.append('Improve technical answers')
    if grammar_score < 90:
        improvement.append('Work on grammar')
    return {
        'technical_score': technical_score,
        'grammar_score': grammar_score,
        'improvement': improvement
    }
