#!/usr/bin/env python3
import sys
import json
import random

def generate_simple_questions(language, num_questions):
    """Generate simple questions for the web app"""
    
    question_bank = {
        'python': [
            {
                'question': 'What is Python?',
                'options': ['Programming language', 'Snake', 'Software', 'Database'],
                'answer': 'Programming language'
            },
            {
                'question': 'How do you create a list in Python?',
                'options': ['[]', '{}', '()', '""'],
                'answer': '[]'
            },
            {
                'question': 'What keyword defines a function in Python?',
                'options': ['def', 'function', 'fun', 'define'],
                'answer': 'def'
            },
            {
                'question': 'Which operator is used for exponentiation in Python?',
                'options': ['**', '^', 'exp', 'pow'],
                'answer': '**'
            },
            {
                'question': 'What is the correct syntax for a comment in Python?',
                'options': ['# comment', '// comment', '/* comment */', '<!-- comment -->'],
                'answer': '# comment'
            }
        ],
        'java': [
            {
                'question': 'What is Java?',
                'options': ['Programming language', 'Coffee', 'Operating system', 'Database'],
                'answer': 'Programming language'
            },
            {
                'question': 'Which keyword is used to define a class in Java?',
                'options': ['class', 'Class', 'define', 'object'],
                'answer': 'class'
            },
            {
                'question': 'What is the entry point of a Java application?',
                'options': ['main() method', 'start() method', 'run() method', 'init() method'],
                'answer': 'main() method'
            },
            {
                'question': 'Which access modifier makes a member accessible everywhere?',
                'options': ['public', 'private', 'protected', 'default'],
                'answer': 'public'
            },
            {
                'question': 'What is used to create an object in Java?',
                'options': ['new keyword', 'create keyword', 'object keyword', 'make keyword'],
                'answer': 'new keyword'
            }
        ],
        'javascript': [
            {
                'question': 'What is JavaScript?',
                'options': ['Programming language', 'Java variant', 'Coffee script', 'Database'],
                'answer': 'Programming language'
            },
            {
                'question': 'How do you declare a variable in modern JavaScript?',
                'options': ['let', 'var', 'const', 'All of the above'],
                'answer': 'All of the above'
            },
            {
                'question': 'What does DOM stand for?',
                'options': ['Document Object Model', 'Data Object Model', 'Dynamic Object Model', 'Direct Object Model'],
                'answer': 'Document Object Model'
            },
            {
                'question': 'Which method is used to add an element to the end of an array?',
                'options': ['push()', 'add()', 'append()', 'insert()'],
                'answer': 'push()'
            },
            {
                'question': 'What is the correct way to write a JavaScript function?',
                'options': ['function myFunction()', 'def myFunction()', 'function = myFunction()', 'create myFunction()'],
                'answer': 'function myFunction()'
            }
        ],
        'c': [
            {
                'question': 'What is C?',
                'options': ['Programming language', 'Operating system', 'Database', 'Hardware'],
                'answer': 'Programming language'
            },
            {
                'question': 'Which header file is needed for printf()?',
                'options': ['stdio.h', 'stdlib.h', 'string.h', 'math.h'],
                'answer': 'stdio.h'
            },
            {
                'question': 'What is the correct syntax to declare a pointer in C?',
                'options': ['int *p', 'int p*', '*int p', 'pointer int p'],
                'answer': 'int *p'
            },
            {
                'question': 'Which function is used to allocate memory dynamically?',
                'options': ['malloc()', 'alloc()', 'memory()', 'new()'],
                'answer': 'malloc()'
            },
            {
                'question': 'What does the & operator do in C?',
                'options': ['Address of operator', 'Bitwise AND', 'Logical AND', 'Reference operator'],
                'answer': 'Address of operator'
            }
        ]
    }
    
    # Get questions for the specified language
    questions = question_bank.get(language.lower(), question_bank['python'])
    
    # Randomly select the requested number of questions
    selected_questions = random.sample(questions, min(num_questions, len(questions)))
    
    return selected_questions

if __name__ == '__main__':
    if len(sys.argv) < 3:
        print(json.dumps({"error": "Usage: python simple_questions.py <language> <num_questions>"}))
        sys.exit(1)
    
    language = sys.argv[1]
    num_questions = int(sys.argv[2])
    
    try:
        questions = generate_simple_questions(language, num_questions)
        print(json.dumps(questions, indent=2))
    except Exception as e:
        print(json.dumps({"error": str(e)}))
        sys.exit(1)