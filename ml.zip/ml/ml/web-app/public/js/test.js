// This file manages the test-taking process, including displaying questions, recording answers, and transitioning between the two rounds of the test.

let currentRound = 1;
let programmingAnswers = [];
let interviewAnswers = [];
let interviewGrammarResults = [];
let interviewCurrentIndex = 0;
let interviewTranscript = '';
let recognition = null;
let mcqCurrentIndex = 0;

let programmingQuestions = [];
let programmingOptions = [];
let programmingCorrectAnswers = [];

// Background animation management
let selectedLanguage = 'Python'; // Default language
let backgroundAnimationActive = true;

// Language-specific background icons
const languageIcons = {
    'Java': ['JAVA', 'CLASS', 'PUBLIC', 'STATIC', 'VOID', 'IMPORT', '{}', 'NEW', 'EXTENDS', 'IMPLEMENTS'],
    'Python': ['PYTHON', 'DEF', 'CLASS', 'IMPORT', 'FOR', 'IF', 'ELSE', 'WHILE', '[]', 'PRINT'],
    'C': ['C', 'MAIN', 'PRINTF', 'SCANF', 'INT', 'CHAR', 'WHILE', 'FOR', 'IF', 'STRUCT'],
    'JavaScript': ['JS', 'FUNCTION', 'VAR', 'LET', 'CONST', 'ASYNC', 'AWAIT', 'PROMISE', '=>', '{}']
};

// Function to update background based on selected language
function updateBackgroundForLanguage(language) {
    selectedLanguage = language;
    const programmingBg = document.querySelector('.programming-bg');
    if (programmingBg && languageIcons[language]) {
        const icons = languageIcons[language];
        const codeIcons = programmingBg.querySelectorAll('.code-icon');
        
        codeIcons.forEach((icon, index) => {
            if (icons[index]) {
                icon.textContent = icons[index];
            }
        });
    }
}

// Function to toggle background animation intensity
function setBackgroundIntensity(intense = false) {
    const codeIcons = document.querySelectorAll('.code-icon');
    codeIcons.forEach(icon => {
        if (intense) {
            icon.style.opacity = '0.3';
            icon.style.animationDuration = '8s';
        } else {
            icon.style.opacity = '0.1';
            icon.style.animationDuration = '15s';
        }
    });
}

// Function to create dynamic background effects during questions
function activateQuestionBackground() {
    setBackgroundIntensity(true);
    setTimeout(() => setBackgroundIntensity(false), 2000);
}

// Sample questions for voice-based interview questions (10 only)
const interviewQuestions = [
    "Tell me about yourself.",
    "What are your strengths and weaknesses?",
    "Why do you want to work here?",
    "Describe a challenging situation you faced and how you handled it.",
    "Where do you see yourself in five years?",
    "What is your greatest achievement?",
    "How do you handle stress and pressure?",
    "Describe a time when you worked as part of a team.",
    "What motivates you?",
    "How do you prioritize your work?"
];


// Function to start the test
async function startTest() {
    console.log('🚀 startTest() function called');
    const selectedCourse = localStorage.getItem('selectedLanguage') || localStorage.getItem('selectedCourse') || 'python';
    console.log('📝 Selected course from localStorage:', selectedCourse);
    
    // Normalize language name for display
    let languageDisplayName = selectedCourse.charAt(0).toUpperCase() + selectedCourse.slice(1);
    if (selectedCourse === 'javascript') {
        languageDisplayName = 'JavaScript';
    }
    console.log('🎯 Language display name:', languageDisplayName);
    
    // Update background for selected language
    updateBackgroundForLanguage(languageDisplayName);
    
    // Activate background animation for test start
    activateQuestionBackground();
    
    console.log(`Starting Round 1 test for ${selectedCourse} with 15 random questions`);
    
    // Show loading message
    const questionsContainer = document.getElementById('questions-container');
    if (!questionsContainer) {
        console.error('❌ CRITICAL: questions-container element not found!');
        return;
    }
    console.log('✅ Found questions-container element');
    
    questionsContainer.innerHTML = `
        <div style="text-align: center; padding: 2em; color: #63b3ed;">
            <h3>Loading ${languageDisplayName} Questions...</h3>
            <p>Generating 15 random questions for Round 1...</p>
            <div style="margin-top: 1em;">
                <div style="width: 200px; height: 4px; background: rgba(255,255,255,0.2); border-radius: 2px; margin: 0 auto;">
                    <div id="loading-progress" style="width: 0%; height: 100%; background: linear-gradient(90deg, #63b3ed, #3b82f6); border-radius: 2px; transition: width 0.5s ease;"></div>
                </div>
            </div>
        </div>
    `;
    
    console.log('✅ Loading message displayed');
    
    // Animate loading progress
    let progress = 0;
    const loadingInterval = setInterval(() => {
        progress += 10;
        const progressBar = document.getElementById('loading-progress');
        if (progressBar) {
            progressBar.style.width = progress + '%';
        }
        if (progress >= 100) {
            clearInterval(loadingInterval);
        }
    }, 100);
    
    try {
        console.log('Fetching 15 random questions from API...');
        const response = await fetch('http://127.0.0.1:3000/api/generate-questions', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                language: selectedCourse,
                num_questions: 15  // Always request exactly 15 questions for Round 1
            })
        });
        
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        
        const data = await response.json();
        console.log('API Response:', data);
        console.log('Response status:', data.status);
        console.log('Questions received:', data.questions ? data.questions.length : 'NONE');
        console.log('Questions array:', data.questions);
        
        if (data.questions && data.questions.length > 0) {
            // Use questions from Node.js server - ensure exactly 15 questions
            const selectedQuestions = data.questions.slice(0, 15);
            programmingQuestions = selectedQuestions.map(q => q.question);
            programmingOptions = selectedQuestions.map(q => q.options);
            programmingCorrectAnswers = selectedQuestions.map(q => q.answer);
            
            console.log(`✅ Successfully loaded ${programmingQuestions.length} random questions for ${selectedCourse} Round 1`);
            console.log('Sample question:', programmingQuestions[0]);
            console.log('Sample options:', programmingOptions[0]);
            console.log('Sample answer:', programmingCorrectAnswers[0]);
            
            // Store enhanced question metadata for reporting
            const questionsWithDifficulty = selectedQuestions.map((q, idx) => ({
                ...q,
                index: idx,
                round: 1,
                type: 'random_generated'
            }));
            
            localStorage.setItem('questionMetadata', JSON.stringify(questionsWithDifficulty));
            localStorage.setItem('generatorType', data.generator || 'random');
            
        } else {
            console.error('❌ No questions in API response!');
            throw new Error(`Invalid API response: ${JSON.stringify(data)}`);
        }
        
    } catch (err) {
        console.error('API call failed:', err);
        console.log('Using local fallback questions for Round 1');
        
        // Enhanced fallback questions based on language - ensure exactly 15 questions
        generateFallbackQuestions(selectedCourse);
    }
    
    // Validate that we have exactly 15 questions
    if (!programmingQuestions || programmingQuestions.length === 0) {
        console.error('No questions available after all attempts! Generating emergency questions...');
        generateEmergencyQuestions(selectedCourse);
    }
    
    // Ensure we have exactly 15 questions (truncate if more, pad if less)
    if (programmingQuestions.length > 15) {
        programmingQuestions = programmingQuestions.slice(0, 15);
        programmingOptions = programmingOptions.slice(0, 15);
        programmingCorrectAnswers = programmingCorrectAnswers.slice(0, 15);
        console.log('Truncated to exactly 15 questions');
    } else if (programmingQuestions.length < 15) {
        // Pad with repeated questions to reach 15
        const needed = 15 - programmingQuestions.length;
        for (let i = 0; i < needed; i++) {
            const sourceIndex = i % programmingQuestions.length;
            programmingQuestions.push(`${programmingQuestions[sourceIndex]} (Variant ${i + 1})`);
            programmingOptions.push([...programmingOptions[sourceIndex]]);
            programmingCorrectAnswers.push(programmingCorrectAnswers[sourceIndex]);
        }
        console.log(`Padded to exactly 15 questions (added ${needed} variants)`);
    }
    
    console.log(`Final Round 1 validation:`);
    console.log(`- Questions array:`, programmingQuestions);
    console.log(`- Options array:`, programmingOptions);  
    console.log(`- Answers array:`, programmingCorrectAnswers);
    console.log(`- Question count: ${programmingQuestions ? programmingQuestions.length : 0}`);
    
    if (programmingQuestions && programmingQuestions.length > 0) {
        console.log('Sample first question:', programmingQuestions[0]);
        console.log('Sample first options:', programmingOptions[0]);
    }
    
    // Initialize test state
    mcqCurrentIndex = 0;
    programmingAnswers = Array(15).fill(null);  // Always 15 slots for Round 1
    
    // Clear loading message and display questions after progress completes
    setTimeout(() => {
        console.log('About to display Round 1 questions...');
        displayQuestions();
    }, 1200);
}

// Emergency question generator for when everything fails
function generateEmergencyQuestions(language) {
    console.log(`Generating emergency questions for ${language}`);
    
    const emergency = {
        'python': {
            questions: [
                'What is Python?',
                'How do you create a list in Python?',
                'What keyword defines a function in Python?',
                'What is the correct indentation in Python?',
                'How do you comment in Python?',
                'What is a variable in Python?',
                'Which operator is used for exponentiation?',
                'What does len() function return?',
                'How do you import a module?',
                'What is a dictionary in Python?',
                'How do you create a tuple?',
                'What is a Python class?',
                'Which method adds to a list?',
                'What is string concatenation?',
                'How do you handle exceptions?'
            ],
            options: [
                ['Programming language', 'Snake', 'Software', 'Database'],
                ['[]', '{}', '()', '""'],
                ['def', 'function', 'define', 'func'],
                ['Spaces or tabs', 'Semicolons', 'Brackets', 'Parentheses'],
                ['#', '//', '/* */', '--'],
                ['Storage location', 'Function', 'Class', 'Module'],
                ['**', '^', 'pow', 'exp'],
                ['Length/size', 'Type', 'Value', 'None'],
                ['import', 'include', 'require', 'load'],
                ['Key-value pairs', 'List', 'String', 'Number'],
                ['()', '[]', '{}', '""'],
                ['Blueprint for objects', 'Function', 'Variable', 'Module'],
                ['append()', 'add()', 'insert()', 'push()'],
                ['+ operator', 'concat()', 'join()', 'merge()'],
                ['try-except', 'if-else', 'while', 'for']
            ],
            answers: ['Programming language', '[]', 'def', 'Spaces or tabs', '#', 'Storage location', '**', 'Length/size', 'import', 'Key-value pairs', '()', 'Blueprint for objects', 'append()', '+ operator', 'try-except']
        },
        'java': {
            questions: [
                'What is Java?',
                'How do you declare a variable in Java?',
                'What is the main method in Java?',
                'How do you create a class in Java?',
                'What is inheritance in Java?',
                'Which keyword creates constants?',
                'What is the JVM?',
                'How do you handle exceptions?',
                'What is an interface?',
                'What is polymorphism?',
                'How do you create an array?',
                'What is encapsulation?',
                'Which access modifier is most restrictive?',
                'What is method overloading?',
                'How do you create an object?'
            ],
            options: [
                ['Programming language', 'Coffee', 'Island', 'Framework'],
                ['datatype name', 'name datatype', 'var name', 'let name'],
                ['Entry point', 'Constructor', 'Destructor', 'Method'],
                ['class Name {}', 'Class Name', 'new class', 'define class'],
                ['Code reuse', 'Encapsulation', 'Abstraction', 'Interface'],
                ['final', 'const', 'static', 'var'],
                ['Virtual machine', 'Compiler', 'IDE', 'Framework'],
                ['try-catch', 'if-else', 'switch', 'for'],
                ['Contract', 'Class', 'Method', 'Variable'],
                ['Many forms', 'Encapsulation', 'Inheritance', 'Abstraction'],
                ['int[] arr', 'array int', 'int arr[]', 'Both A and C'],
                ['Data hiding', 'Inheritance', 'Polymorphism', 'Abstraction'],
                ['private', 'public', 'protected', 'default'],
                ['Same name different params', 'Different names', 'Same params', 'None'],
                ['new keyword', 'create', 'make', 'object()']
            ],
            answers: ['Programming language', 'datatype name', 'Entry point', 'class Name {}', 'Code reuse', 'final', 'Virtual machine', 'try-catch', 'Contract', 'Many forms', 'Both A and C', 'Data hiding', 'private', 'Same name different params', 'new keyword']
        },
        'javascript': {
            questions: [
                'What is JavaScript?',
                'How do you declare a variable?',
                'What is a function in JavaScript?',
                'How do you create an array?',
                'What is an object?',
                'What is the DOM?',
                'How do you handle events?',
                'What is JSON?',
                'What are promises?',
                'What is async/await?',
                'How do you add array elements?',
                'What is typeof operator?',
                'How do you create a loop?',
                'What is string concatenation?',
                'How do you access object properties?'
            ],
            options: [
                ['Programming language', 'Java subset', 'Coffee script', 'Database'],
                ['var/let/const', 'variable', 'declare', 'def'],
                ['Code block', 'Variable', 'Object', 'Array'],
                ['[]', '{}', '()', '""'],
                ['Key-value pairs', 'Array', 'Function', 'Variable'],
                ['Document model', 'Database', 'Framework', 'Library'],
                ['Event listeners', 'Functions', 'Variables', 'Objects'],
                ['Data format', 'Framework', 'Library', 'Method'],
                ['Async handling', 'Variables', 'Functions', 'Objects'],
                ['Async syntax', 'Variables', 'Functions', 'Objects'],
                ['push()', 'add()', 'append()', 'insert()'],
                ['Check data type', 'Create variable', 'Convert type', 'Delete variable'],
                ['for/while', 'if/else', 'switch', 'function'],
                ['+ operator', 'concat()', 'join()', 'Both A and B'],
                ['dot notation', 'bracket notation', 'Both A and B', 'arrow notation']
            ],
            answers: ['Programming language', 'var/let/const', 'Code block', '[]', 'Key-value pairs', 'Document model', 'Event listeners', 'Data format', 'Async handling', 'Async syntax', 'push()', 'Check data type', 'for/while', 'Both A and B', 'Both A and B']
        },
        'c': {
            questions: [
                'What is C programming?',
                'How do you include headers?',
                'What is the main function?',
                'How do you declare variables?',
                'What are pointers?',
                'How do you allocate memory?',
                'What does printf do?',
                'How do you compile C programs?',
                'What are arrays?',
                'What is a struct?',
                'How do you create constants?',
                'What is a loop?',
                'How do you read input?',
                'What is string handling?',
                'How do you define macros?'
            ],
            options: [
                ['Programming language', 'Letter', 'Vitamin', 'Database'],
                ['#include', '#import', 'include', 'import'],
                ['Entry point', 'Function', 'Variable', 'Header'],
                ['type name', 'name type', 'var name', 'let name'],
                ['Memory addresses', 'Variables', 'Functions', 'Arrays'],
                ['malloc()', 'alloc()', 'memory()', 'new()'],
                ['Print output', 'Read input', 'Calculate', 'Compare'],
                ['gcc compiler', 'javac', 'node', 'python'],
                ['Collections', 'Variables', 'Functions', 'Pointers'],
                ['Data structure', 'Function', 'Variable', 'Pointer'],
                ['const keyword', '#define', 'Both A and B', 'final'],
                ['Repetition structure', 'Decision structure', 'Sequential', 'Random'],
                ['scanf()', 'printf()', 'getchar()', 'All of above'],
                ['Character arrays', 'Numbers', 'Pointers', 'Functions'],
                ['#define', '#macro', 'define', 'macro']
            ],
            answers: ['Programming language', '#include', 'Entry point', 'type name', 'Memory addresses', 'malloc()', 'Print output', 'gcc compiler', 'Collections', 'Data structure', 'Both A and B', 'Repetition structure', 'scanf()', 'Character arrays', '#define']
        }
    };
    
    const langData = emergency[language] || emergency['python'];
    programmingQuestions = langData.questions;
    programmingOptions = langData.options;
    programmingCorrectAnswers = langData.answers;
    
    console.log(`Generated exactly ${programmingQuestions.length} emergency questions for Round 1`);
    console.log('Emergency questions loaded:', programmingQuestions);
}

// Generate better fallback questions based on language
function generateFallbackQuestions(language) {
    const fallbackTemplates = {
        'python': {
            questions: [
                "What is the correct way to create a list in Python?",
                "Which keyword is used to define a function in Python?",
                "What is the difference between 'is' and '==' in Python?",
                "How do you handle exceptions in Python?",
                "What is a Python decorator?",
                "Which data structure is ordered and mutable in Python?",
                "What does the 'self' parameter represent in Python classes?",
                "How do you create a virtual environment in Python?",
                "What is list comprehension in Python?",
                "Which module is used for regular expressions in Python?",
                "What is the purpose of __init__ method?",
                "How do you read a file in Python?",
                "What is the difference between append() and extend()?",
                "Which function converts a string to lowercase?",
                "What is the output of print(type([])).__name__?"
            ],
            options: [
                ["[]", "{}", "()", "None"],
                ["def", "function", "define", "func"],
                ["'is' checks identity, '==' checks value", "Both are same", "'is' checks value", "No difference"],
                ["try-except", "if-else", "while", "for"],
                ["Function modifier", "Variable", "Class", "Module"],
                ["List", "Tuple", "Set", "Dictionary"],
                ["Current instance", "Class name", "Function", "Variable"],
                ["venv module", "pip install", "python -m", "virtualenv only"],
                ["Compact way to create lists", "Loop structure", "Function type", "Class method"],
                ["re", "regex", "regexp", "regular"],
                ["Constructor method", "Destructor", "Class variable", "Instance method"],
                ["open() function", "read() only", "file() function", "import file"],
                ["append() adds one item, extend() adds multiple", "Both same", "extend() adds one", "No difference"],
                ["lower()", "lowercase()", "toLower()", "downcase()"],
                ["list", "array", "List", "[]"]
            ],
            answers: ["[]", "def", "'is' checks identity, '==' checks value", "try-except", "Function modifier", "List", "Current instance", "venv module", "Compact way to create lists", "re", "Constructor method", "open() function", "append() adds one item, extend() adds multiple", "lower()", "list"]
        },
        'java': {
            questions: [
                "Which keyword is used to create a constant in Java?",
                "What is the correct way to declare an array in Java?",
                "Which access modifier makes a member accessible only within the same class?",
                "What is method overloading in Java?",
                "Which keyword is used for inheritance in Java?",
                "What is the difference between ArrayList and LinkedList?",
                "Which interface must be implemented for custom sorting?",
                "What is the purpose of 'static' keyword?",
                "How do you handle exceptions in Java?",
                "What is a constructor in Java?",
                "Which collection allows duplicate elements?",
                "What is encapsulation in Java?",
                "Which keyword prevents method overriding?",
                "What is the difference between == and equals()?",
                "Which loop is guaranteed to execute at least once?"
            ],
            options: [
                ["final", "const", "static", "readonly"],
                ["int[] arr", "int arr[]", "Both are correct", "array<int> arr"],
                ["private", "protected", "public", "default"],
                ["Same method name, different parameters", "Different method names", "Same parameters", "None"],
                ["extends", "implements", "inherits", "derives"],
                ["ArrayList is faster for access, LinkedList for insertion", "No difference", "LinkedList is always faster", "ArrayList is always faster"],
                ["Comparable", "Comparator", "Sortable", "Ordered"],
                ["Belongs to class, not instance", "Makes variable constant", "Prevents inheritance", "All of above"],
                ["try-catch", "if-else", "switch", "while"],
                ["Special method for object creation", "Regular method", "Variable", "Class"],
                ["ArrayList", "Set", "Map", "All collections"],
                ["Hiding internal details", "Inheritance concept", "Polymorphism", "Abstraction"],
                ["final", "static", "private", "abstract"],
                ["== compares reference, equals() compares content", "Both same", "== compares content", "No difference"],
                ["do-while", "while", "for", "enhanced for"]
            ],
            answers: ["final", "Both are correct", "private", "Same method name, different parameters", "extends", "ArrayList is faster for access, LinkedList for insertion", "Comparable", "Belongs to class, not instance", "try-catch", "Special method for object creation", "ArrayList", "Hiding internal details", "final", "== compares reference, equals() compares content", "do-while"]
        },
        'javascript': {
            questions: [
                "What is the difference between let and var?",
                "Which method adds an element to the end of an array?",
                "What does '===' operator do?",
                "How do you create a function in JavaScript?",
                "What is a closure in JavaScript?",
                "Which method removes the last element from an array?",
                "What is the difference between null and undefined?",
                "How do you check if a variable is an array?",
                "What is event delegation?",
                "Which keyword creates a constant variable?",
                "What does 'this' refer to in JavaScript?",
                "How do you handle asynchronous operations?",
                "What is hoisting in JavaScript?",
                "Which method creates a new array with modified elements?",
                "What is the purpose of 'use strict'?"
            ],
            options: [
                ["let has block scope, var has function scope", "No difference", "let is faster", "var is newer"],
                ["push()", "add()", "append()", "insert()"],
                ["Strict equality comparison", "Assignment", "Loose equality", "Type conversion"],
                ["function name() {}", "def name():", "func name() {}", "function: name() {}"],
                ["Function with access to outer scope", "Loop structure", "Object type", "Event handler"],
                ["pop()", "remove()", "delete()", "splice()"],
                ["null is assigned, undefined is unassigned", "Both are same", "null is error", "undefined is error"],
                ["Array.isArray()", "typeof", "instanceof", "isArray()"],
                ["Handling events at parent element", "Creating events", "Preventing events", "Event timing"],
                ["const", "let", "final", "constant"],
                ["Current context object", "Global object", "Function", "Variable"],
                ["Promises, async/await, callbacks", "Loops", "Conditions", "Functions"],
                ["Variable declarations moved to top", "Error handling", "Function creation", "Object creation"],
                ["map()", "forEach()", "filter()", "reduce()"],
                ["Enables strict mode parsing", "Creates constants", "Prevents errors", "Enables debugging"]
            ],
            answers: ["let has block scope, var has function scope", "push()", "Strict equality comparison", "function name() {}", "Function with access to outer scope", "pop()", "null is assigned, undefined is unassigned", "Array.isArray()", "Handling events at parent element", "const", "Current context object", "Promises, async/await, callbacks", "Variable declarations moved to top", "map()", "Enables strict mode parsing"]
        },
        'c': {
            questions: [
                "Which header file is required for printf()?",
                "What is the correct way to declare a pointer?",
                "Which function allocates memory dynamically?",
                "What does '&' operator do?",
                "Which loop is entry-controlled?",
                "What is the size of int in most systems?",
                "Which function is used to find string length?",
                "What does 'static' keyword do in C?",
                "How do you pass array to a function?",
                "What is the difference between malloc() and calloc()?",
                "Which operator is used for member access?",
                "What does 'const' keyword indicate?",
                "Which function reads a character from input?",
                "What is a structure in C?",
                "Which operator has the highest precedence?"
            ],
            options: [
                ["<stdio.h>", "<stdlib.h>", "<string.h>", "<conio.h>"],
                ["int *ptr", "int ptr*", "*int ptr", "ptr* int"],
                ["malloc()", "alloc()", "memory()", "new()"],
                ["Address of operator", "Logical AND", "Bitwise AND", "Reference"],
                ["while", "do-while", "for", "All except do-while"],
                ["4 bytes", "2 bytes", "8 bytes", "1 byte"],
                ["strlen()", "length()", "size()", "len()"],
                ["Limits scope to file", "Makes constant", "Allocates memory", "Creates global"],
                ["Pass array name", "Pass &array", "Pass array[]", "Cannot pass arrays"],
                ["malloc() doesn't initialize, calloc() initializes to zero", "No difference", "calloc() is faster", "malloc() is newer"],
                [".", "->", "Both", ":"],
                ["Variable cannot be modified", "Variable is global", "Variable is local", "Variable is dynamic"],
                ["getchar()", "scanf()", "gets()", "read()"],
                ["User-defined data type", "Built-in type", "Function type", "Array type"],
                ["()", "++/--", "*", "All have same"]
            ],
            answers: ["<stdio.h>", "int *ptr", "malloc()", "Address of operator", "All except do-while", "4 bytes", "strlen()", "Limits scope to file", "Pass array name", "malloc() doesn't initialize, calloc() initializes to zero", "Both", "Variable cannot be modified", "getchar()", "User-defined data type", "()"]
        }
    };
    
    const template = fallbackTemplates[language] || fallbackTemplates['python'];
    programmingQuestions = template.questions;
    programmingOptions = template.options;
    programmingCorrectAnswers = template.answers;
    
    console.log(`Generated ${programmingQuestions.length} fallback questions for ${language}`);
}

// Function to display questions based on the current round
function displayQuestions() {
    const questionsContainer = document.getElementById('questions-container');
    
    console.log('🎯 DisplayQuestions called with:', {
        currentRound,
        questionsLength: programmingQuestions ? programmingQuestions.length : 'NULL',
        currentIndex: mcqCurrentIndex,
        questionsArray: programmingQuestions,
        optionsArray: programmingOptions,
        answersArray: programmingCorrectAnswers
    });
    
    // Validate that we have questions
    if (!programmingQuestions || programmingQuestions.length === 0) {
        console.error('❌ No questions available!');
        questionsContainer.innerHTML = `
            <div style="text-align: center; padding: 2em; color: #ef4444;">
                <h3>⚠️ No Questions Available</h3>
                <p>Unable to load questions. Please refresh the page or try again.</p>
                <p style="font-size: 0.9em; opacity: 0.8;">Debug: programmingQuestions = ${programmingQuestions}</p>
                <button onclick="location.reload()" style="
                    background: #63b3ed; 
                    color: white; 
                    border: none; 
                    padding: 0.8em 1.5em; 
                    border-radius: 8px; 
                    cursor: pointer; 
                    margin-top: 1em;
                ">Refresh Page</button>
                <br><br>
                <button onclick="generateEmergencyQuestions('python'); displayQuestions();" style="
                    background: #f59e0b; 
                    color: white; 
                    border: none; 
                    padding: 0.8em 1.5em; 
                    border-radius: 8px; 
                    cursor: pointer; 
                    margin-top: 1em;
                ">Load Emergency Questions</button>
            </div>
        `;
        return;
    }
    
    console.log('✅ Questions validated, displaying Round', currentRound);
    questionsContainer.innerHTML = '';

    // Activate background animation when new question appears
    activateQuestionBackground();

    if (currentRound === 1) {
        // Show only one MCQ at a time
        const index = mcqCurrentIndex;
        const questionElement = document.createElement('div');
        
        // Get question metadata if available
        const metadata = JSON.parse(localStorage.getItem('questionMetadata') || '[]');
        const currentQuestionMeta = metadata[index] || {};
        
        // Create question header with difficulty indicator
        let questionHeader = `<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1em;">`;
        questionHeader += `<span style="color: #63b3ed; font-weight: bold;">Question ${index + 1} of ${programmingQuestions.length}</span>`;
        
        if (currentQuestionMeta.difficulty) {
            const difficultyColor = {
                'easy': '#10b981',
                'medium': '#f59e0b', 
                'hard': '#ef4444'
            };
            const color = difficultyColor[currentQuestionMeta.difficulty] || '#6b7280';
            questionHeader += `<span style="color: ${color}; font-size: 0.9em; padding: 0.2em 0.6em; background: rgba(255,255,255,0.1); border-radius: 12px;">
                ${currentQuestionMeta.difficulty?.toUpperCase() || 'MEDIUM'}
            </span>`;
        }
        questionHeader += `</div>`;
        
        // Add progress bar
        const progress = ((index + 1) / programmingQuestions.length) * 100;
        questionHeader += `<div style="width: 100%; background: rgba(255,255,255,0.1); border-radius: 10px; height: 8px; margin-bottom: 1.5em;">
            <div style="width: ${progress}%; background: linear-gradient(90deg, #63b3ed, #3b82f6); height: 100%; border-radius: 10px; transition: width 0.3s ease;"></div>
        </div>`;
        
        questionElement.innerHTML = questionHeader;
        questionElement.innerHTML += `<div style="background: rgba(255,255,255,0.05); padding: 1.2em; border-radius: 12px; margin-bottom: 1.5em;">
            <p style="font-size: 1.1em; line-height: 1.6; margin: 0;"><strong>${programmingQuestions[index]}</strong></p>
        </div>`;
        
        // Add options with better styling
        const optionsContainer = document.createElement('div');
        optionsContainer.style.cssText = 'display: flex; flex-direction: column; gap: 0.8em;';
        
        programmingOptions[index].forEach((option, optIdx) => {
            const optionLabel = document.createElement('label');
            optionLabel.style.cssText = `
                display: flex; 
                align-items: center; 
                padding: 1em; 
                background: rgba(255,255,255,0.05); 
                border: 2px solid transparent;
                border-radius: 10px; 
                cursor: pointer; 
                transition: all 0.3s ease;
                font-size: 1em;
            `;
            
            const isChecked = programmingAnswers[index] === option;
            if (isChecked) {
                optionLabel.style.borderColor = '#63b3ed';
                optionLabel.style.background = 'rgba(99, 179, 237, 0.15)';
            }
            
            optionLabel.innerHTML = `
                <input type="radio" name="answer" value="${option}" ${isChecked ? 'checked' : ''} 
                       style="margin-right: 0.8em; transform: scale(1.2);">
                <span>${option}</span>
            `;
            
            // Add hover effect
            optionLabel.addEventListener('mouseenter', () => {
                if (!isChecked) {
                    optionLabel.style.background = 'rgba(255,255,255,0.1)';
                    optionLabel.style.borderColor = 'rgba(99, 179, 237, 0.5)';
                }
            });
            
            optionLabel.addEventListener('mouseleave', () => {
                if (!isChecked) {
                    optionLabel.style.background = 'rgba(255,255,255,0.05)';
                    optionLabel.style.borderColor = 'transparent';
                }
            });
            
            optionsContainer.appendChild(optionLabel);
        });
        
        questionElement.appendChild(optionsContainer);

        // Navigation and submit with skip option
        const navDiv = document.createElement('div');
        navDiv.style.cssText = 'margin-top: 1.5em; display: flex; gap: 1em; flex-wrap: wrap; justify-content: space-between;';
        
        // Left side buttons (Previous)
        const leftButtons = document.createElement('div');
        leftButtons.style.cssText = 'display: flex; gap: 0.5em;';
        if (index > 0) {
            const prevBtn = document.createElement('button');
            prevBtn.innerText = 'Previous';
            prevBtn.style.cssText = 'background: #6b7280; color: white; border: none; padding: 0.8em 1.5em; border-radius: 8px; cursor: pointer;';
            prevBtn.onclick = (e) => {
                if (e) e.preventDefault();
                saveCurrentMcqAnswer();
                mcqCurrentIndex = Math.max(0, mcqCurrentIndex - 1);
                displayQuestions();
            };
            leftButtons.appendChild(prevBtn);
        }
        
        // Center button (Skip)
        const skipBtn = document.createElement('button');
        skipBtn.innerText = 'Skip Question';
        skipBtn.style.cssText = 'background: #f59e0b; color: white; border: none; padding: 0.8em 1.5em; border-radius: 8px; cursor: pointer; font-weight: bold;';
        skipBtn.onclick = (e) => {
            if (e) e.preventDefault();
            // Mark as skipped (special value)
            programmingAnswers[mcqCurrentIndex] = 'SKIPPED';
            if (index < programmingQuestions.length - 1) {
                mcqCurrentIndex = Math.min(programmingQuestions.length - 1, mcqCurrentIndex + 1);
                displayQuestions();
            } else {
                currentRound++;
                // Reset interview round state
                interviewAnswers = [];
                interviewGrammarResults = [];
                interviewCurrentIndex = 0;
                interviewTranscript = '';
                displayQuestions();
            }
        };
        
        // Right side button (Next/Submit)
        const rightButtons = document.createElement('div');
        rightButtons.style.cssText = 'display: flex; gap: 0.5em;';
        const nextBtn = document.createElement('button');
        nextBtn.innerText = (index < programmingQuestions.length - 1) ? 'Next' : 'Submit Round 1';
        nextBtn.style.cssText = 'background: #63b3ed; color: white; border: none; padding: 0.8em 1.5em; border-radius: 8px; cursor: pointer; font-weight: bold;';
        nextBtn.onclick = (e) => {
            if (e) e.preventDefault();
            saveCurrentMcqAnswer();
            if (index < programmingQuestions.length - 1) {
                mcqCurrentIndex = Math.min(programmingQuestions.length - 1, mcqCurrentIndex + 1);
                displayQuestions();
            } else {
                currentRound++;
                // Reset interview round state
                interviewAnswers = [];
                interviewGrammarResults = [];
                interviewCurrentIndex = 0;
                interviewTranscript = '';
                displayQuestions();
            }
        };
        rightButtons.appendChild(nextBtn);
        
        navDiv.appendChild(leftButtons);
        navDiv.appendChild(skipBtn);
        navDiv.appendChild(rightButtons);
        questionElement.appendChild(navDiv);
        questionsContainer.appendChild(questionElement);
    } else {
        // Interactive interview round
        showInterviewQuestion();
    }
}

function saveCurrentMcqAnswer() {
    const selected = document.querySelector('input[name="answer"]:checked');
    programmingAnswers[mcqCurrentIndex] = selected ? selected.value : null;
}

function showInterviewQuestion() {
    const questionsContainer = document.getElementById('questions-container');
    questionsContainer.innerHTML = '';
    const idx = interviewCurrentIndex;
    const question = interviewQuestions[idx];
    const questionElement = document.createElement('div');
    questionElement.innerHTML = `<h2>Round 2: Voice-Based Interview Questions</h2><p><b>Question ${idx + 1}:</b> ${question}</p>`;

    // Live transcript box
    const transcriptBox = document.createElement('div');
    transcriptBox.id = 'transcript-box';
    transcriptBox.style.border = '1px solid #ccc';
    transcriptBox.style.padding = '10px';
    transcriptBox.style.margin = '10px 0';
    transcriptBox.style.background = '#f9f9f9';
    transcriptBox.innerHTML = `<b>Your Answer:</b> <span id="transcript-text">${interviewTranscript}</span>`;
    questionElement.appendChild(transcriptBox);

    // Controls (5 buttons including skip)
    const controlsDiv = document.createElement('div');
    controlsDiv.style.marginTop = '1em';
    controlsDiv.style.display = 'grid';
    controlsDiv.style.gridTemplateColumns = 'repeat(auto-fit, minmax(150px, 1fr))';
    controlsDiv.style.gap = '10px';

    // Read aloud
    const readBtn = document.createElement('button');
    readBtn.innerText = 'Read Again';
    readBtn.style.cssText = 'background: #6b7280; color: white; border: none; padding: 0.8em; border-radius: 8px; cursor: pointer;';
    readBtn.onclick = (e) => {
        if (e) e.preventDefault();
        speakText(question);
    };
    controlsDiv.appendChild(readBtn);

    // Start recording
    const recordBtn = document.createElement('button');
    recordBtn.innerText = 'Record Answer';
    recordBtn.style.cssText = 'background: #10b981; color: white; border: none; padding: 0.8em; border-radius: 8px; cursor: pointer;';
    recordBtn.onclick = (e) => {
        if (e) e.preventDefault();
        startSpeechRecognitionLive();
    };
    controlsDiv.appendChild(recordBtn);

    // Reset answer
    const resetBtn = document.createElement('button');
    resetBtn.innerText = 'Reset Answer';
    resetBtn.style.cssText = 'background: #ef4444; color: white; border: none; padding: 0.8em; border-radius: 8px; cursor: pointer;';
    resetBtn.onclick = (e) => {
        if (e) e.preventDefault();
        interviewTranscript = '';
        document.getElementById('transcript-text').innerText = '';
    };
    controlsDiv.appendChild(resetBtn);

    // Skip question
    const skipBtn = document.createElement('button');
    skipBtn.innerText = 'Skip Question';
    skipBtn.style.cssText = 'background: #f59e0b; color: white; border: none; padding: 0.8em; border-radius: 8px; cursor: pointer; font-weight: bold;';
    skipBtn.onclick = async (e) => {
        if (e) e.preventDefault();
        // Mark as skipped
        interviewAnswers[idx] = 'SKIPPED';
        interviewGrammarResults[idx] = { 
            score: 0, 
            issues: ['Question was skipped'], 
            status: 'skipped',
            feedback: 'No evaluation - question skipped'
        };
        interviewTranscript = '';
        if (idx < interviewQuestions.length - 1) {
            interviewCurrentIndex++;
            showInterviewQuestion();
        } else {
            generateReport();
        }
    };
    controlsDiv.appendChild(skipBtn);

    // Submit answer (grammar check and next)
    const submitBtn = document.createElement('button');
    submitBtn.innerText = (idx < interviewQuestions.length - 1) ? 'Submit Answer & Next' : 'Submit & Finish';
    submitBtn.style.cssText = 'background: #63b3ed; color: white; border: none; padding: 0.8em; border-radius: 8px; cursor: pointer; font-weight: bold;';
    submitBtn.onclick = async (e) => {
        if (e) e.preventDefault();
        if (!interviewTranscript) {
            alert('Please record your answer first or skip this question.');
            return;
        }
        // Save answer
        interviewAnswers[idx] = interviewTranscript;
        // Send transcript to grammar detection API
        try {
            const response = await fetch('http://127.0.0.1:3000/api/grammar-check', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ text: interviewTranscript })
            });
            const result = await response.json();
            interviewGrammarResults[idx] = result;
        } catch (err) {
            console.error('Grammar check failed:', err);
            // Fallback grammar analysis
            interviewGrammarResults[idx] = {
                score: 75, // Default score when API fails
                issues: ['Grammar check service unavailable'],
                status: 'error',
                feedback: 'Basic grammar analysis completed'
            };
        }
        interviewTranscript = '';
        if (idx < interviewQuestions.length - 1) {
            interviewCurrentIndex++;
            showInterviewQuestion();
        } else {
            generateReport();
        }
    };
    controlsDiv.appendChild(submitBtn);

    questionElement.appendChild(controlsDiv);
    questionsContainer.appendChild(questionElement);

    // Auto-read question on load
    speakText(question);
}

function startSpeechRecognitionLive() {
    if (!('webkitSpeechRecognition' in window || 'SpeechRecognition' in window)) {
        alert('Speech recognition not supported in this browser.');
        return;
    }
    if (recognition) recognition.abort();
    recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
    recognition.lang = 'en-US';
    recognition.interimResults = true;
    recognition.maxAlternatives = 1;
    recognition.onresult = function(event) {
        let liveText = '';
        for (let i = 0; i < event.results.length; i++) {
            liveText += event.results[i][0].transcript + ' ';
        }
        interviewTranscript = liveText.trim();
        const transcriptElem = document.getElementById('transcript-text');
        if (transcriptElem) transcriptElem.innerText = interviewTranscript;
    };
    recognition.onerror = function(event) {
        alert('Speech recognition error: ' + event.error);
    };
    recognition.onend = function() {
        // Stay on current question, do not reset round or navigation
        // Optionally, you can add a message: 'Recording stopped.'
    };
    // Make sure we do not call displayQuestions or showInterviewQuestion here
    recognition.start();
}

function speakText(text) {
    if ('speechSynthesis' in window) {
        const utter = new SpeechSynthesisUtterance(text);
        window.speechSynthesis.speak(utter);
    }
}

function startSpeechRecognition() {
    if (!('webkitSpeechRecognition' in window || 'SpeechRecognition' in window)) {
        alert('Speech recognition not supported in this browser.');
        return;
    }
    if (recognition) recognition.abort();
    recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
    recognition.lang = 'en-US';
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;
    recognition.onresult = function(event) {
        interviewTranscript = event.results[0][0].transcript;
        document.getElementById('transcript-text').innerText = interviewTranscript;
    };
    recognition.onerror = function(event) {
        alert('Speech recognition error: ' + event.error);
    };
    recognition.start();
}

// Function to submit answers
// submitAnswers is no longer needed for MCQ round

// Function to generate report
function generateReport() {
    // Calculate MCQ score (excluding skipped questions)
    let score = 0;
    let answeredQuestions = 0;
    let skippedQuestions = 0;
    
    programmingAnswers.forEach((ans, idx) => {
        if (ans === 'SKIPPED') {
            skippedQuestions++;
        } else if (ans && ans === programmingCorrectAnswers[idx]) {
            score++;
            answeredQuestions++;
        } else if (ans) {
            answeredQuestions++;
        }
    });
    
    // Calculate interview statistics
    let interviewAnswered = 0;
    let interviewSkipped = 0;
    
    interviewAnswers.forEach(ans => {
        if (ans === 'SKIPPED') {
            interviewSkipped++;
        } else if (ans && ans.trim()) {
            interviewAnswered++;
        }
    });
    
    // Store detailed results for report page
    localStorage.setItem('mcqScore', score);
    localStorage.setItem('mcqTotal', programmingQuestions.length);
    localStorage.setItem('mcqAnswered', answeredQuestions);
    localStorage.setItem('mcqSkipped', skippedQuestions);
    localStorage.setItem('interviewAnswered', interviewAnswered);
    localStorage.setItem('interviewSkipped', interviewSkipped);
    localStorage.setItem('programmingAnswers', JSON.stringify(programmingAnswers));
    localStorage.setItem('interviewAnswers', JSON.stringify(interviewAnswers));
    localStorage.setItem('interviewGrammarResults', JSON.stringify(interviewGrammarResults));
    
    // Store detailed question analysis
    const questionAnalysis = programmingQuestions.map((question, idx) => ({
        question: question,
        userAnswer: programmingAnswers[idx],
        correctAnswer: programmingCorrectAnswers[idx],
        isCorrect: programmingAnswers[idx] === programmingCorrectAnswers[idx],
        isSkipped: programmingAnswers[idx] === 'SKIPPED',
        isAnswered: programmingAnswers[idx] && programmingAnswers[idx] !== 'SKIPPED'
    }));
    
    localStorage.setItem('questionAnalysis', JSON.stringify(questionAnalysis));
    
    // Redirect to report page
    window.location.href = 'report.html';
}

// Initialize background and start the test when the page loads
window.onload = function() {
    // Set initial language from localStorage or URL parameters
    const urlParams = new URLSearchParams(window.location.search);
    const courseParam = urlParams.get('course');
    const selectedCourse = courseParam || localStorage.getItem('selectedCourse') || 'Python';
    
    // Update background immediately
    updateBackgroundForLanguage(selectedCourse);
    
    // Add focus management for background
    const testContainer = document.querySelector('.test-container');
    if (testContainer) {
        testContainer.addEventListener('focus', () => setBackgroundIntensity(false), true);
        testContainer.addEventListener('blur', () => setBackgroundIntensity(true), true);
    }
    
    // Start the test
    startTest();
};

// Add keyboard shortcuts for better test experience
document.addEventListener('keydown', function(event) {
    // Press 'F' to toggle background focus mode
    if (event.key.toLowerCase() === 'f' && event.ctrlKey) {
        event.preventDefault();
        backgroundAnimationActive = !backgroundAnimationActive;
        setBackgroundIntensity(!backgroundAnimationActive);
    }
    
    // Press 'B' to change background theme
    if (event.key.toLowerCase() === 'b' && event.ctrlKey) {
        event.preventDefault();
        const languages = Object.keys(languageIcons);
        const currentIndex = languages.indexOf(selectedLanguage);
        const nextLanguage = languages[(currentIndex + 1) % languages.length];
        updateBackgroundForLanguage(nextLanguage);
    }
});