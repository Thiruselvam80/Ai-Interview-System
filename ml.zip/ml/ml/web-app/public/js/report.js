
document.addEventListener('DOMContentLoaded', function() {
    const technicalScoreElem = document.getElementById('technical-score');
    const technicalFeedbackElem = document.getElementById('technical-feedback');
    const grammarScoreElem = document.getElementById('grammar-score');
    const grammarFeedbackElem = document.getElementById('grammar-feedback');
    const summaryElem = document.getElementById('summary-text');

    // Get enhanced test results
    const mcqScore = parseInt(localStorage.getItem('mcqScore')) || 0;
    const mcqTotal = parseInt(localStorage.getItem('mcqTotal')) || 0;
    const mcqAnswered = parseInt(localStorage.getItem('mcqAnswered')) || 0;
    const mcqSkipped = parseInt(localStorage.getItem('mcqSkipped')) || 0;
    const interviewAnswered = parseInt(localStorage.getItem('interviewAnswered')) || 0;
    const interviewSkipped = parseInt(localStorage.getItem('interviewSkipped')) || 0;
    
    const programmingAnswers = JSON.parse(localStorage.getItem('programmingAnswers')) || [];
    const interviewAnswers = JSON.parse(localStorage.getItem('interviewAnswers')) || [];
    const interviewGrammarResults = JSON.parse(localStorage.getItem('interviewGrammarResults')) || [];
    const questionAnalysis = JSON.parse(localStorage.getItem('questionAnalysis')) || [];

    // Enhanced technical knowledge feedback with skip handling
    const mcqAttempted = mcqTotal - mcqSkipped;
    const mcqPercentage = mcqAttempted > 0 ? (mcqScore / mcqAttempted) * 100 : 0;
    const mcqTotalPercentage = mcqTotal > 0 ? (mcqScore / mcqTotal) * 100 : 0;
    
    technicalScoreElem.innerHTML = `
        <strong>Score:</strong> ${mcqScore} / ${mcqTotal} (${mcqTotalPercentage.toFixed(1)}%)<br>
        <span style="font-size: 0.9em; color: #6b7280;">
            Answered: ${mcqAnswered} | Correct: ${mcqScore} | Skipped: ${mcqSkipped}<br>
            ${mcqAttempted > 0 ? `Accuracy on attempted: ${mcqPercentage.toFixed(1)}%` : 'No questions attempted'}
        </span>
    `;
    
    let technicalFeedback = '';
    if (mcqSkipped === mcqTotal) {
        technicalFeedback = 'All technical questions were skipped. Consider attempting the questions to evaluate your knowledge.';
    } else if (mcqPercentage >= 80) {
        technicalFeedback = 'Excellent technical knowledge! You demonstrate strong understanding of the concepts.';
    } else if (mcqPercentage >= 60) {
        technicalFeedback = 'Good technical knowledge with room for improvement in some areas.';
    } else if (mcqPercentage >= 40) {
        technicalFeedback = 'Basic technical knowledge. Consider reviewing fundamental concepts.';
    } else {
        technicalFeedback = 'Technical knowledge needs significant improvement. Focus on core concepts.';
    }
    
    if (mcqSkipped > 0) {
        technicalFeedback += ` Note: ${mcqSkipped} question(s) were skipped and not evaluated.`;
    }
    
    technicalFeedbackElem.textContent = technicalFeedback;

    // Enhanced grammar analysis with detailed breakdown
    let grammarTotal = 0;
    let grammarCount = 0;
    let grammarIssues = [];
    let grammarDetails = [];
    
    interviewGrammarResults.forEach((result, idx) => {
        if (result && result.status === 'analyzed') {
            grammarTotal += result.score;
            grammarCount++;
            
            const questionNum = idx + 1;
            grammarDetails.push({
                question: questionNum,
                score: result.score,
                feedback: result.feedback,
                issues: result.issues || [],
                wordCount: result.wordCount || 0,
                sentenceCount: result.sentenceCount || 0
            });
            
            if (result.issues && result.issues.length > 0) {
                grammarIssues.push(`Q${questionNum}: ${result.issues.join(', ')}`);
            }
        } else if (result && result.status === 'skipped') {
            grammarDetails.push({
                question: idx + 1,
                score: 0,
                feedback: 'Question skipped',
                issues: ['Not answered'],
                wordCount: 0,
                sentenceCount: 0,
                skipped: true
            });
        }
    });
    
    const grammarAvg = grammarCount > 0 ? Math.round(grammarTotal / grammarCount) : 0;
    const totalInterviewQuestions = interviewAnswers.length;
    
    grammarScoreElem.innerHTML = `
        <strong>Score:</strong> ${grammarAvg} / 100 (Average)<br>
        <span style="font-size: 0.9em; color: #6b7280;">
            Answered: ${interviewAnswered} | Skipped: ${interviewSkipped} | Total: ${totalInterviewQuestions}<br>
            ${grammarCount > 0 ? `Based on ${grammarCount} analyzed response(s)` : 'No responses analyzed'}
        </span>
    `;
    
    let grammarFeedback = '';
    if (interviewSkipped === totalInterviewQuestions) {
        grammarFeedback = 'All interview questions were skipped. Grammar analysis requires spoken responses.';
    } else if (grammarAvg >= 90) {
        grammarFeedback = 'Excellent grammar and communication skills. Your responses are well-structured.';
    } else if (grammarAvg >= 75) {
        grammarFeedback = 'Good grammar with minor areas for improvement.';
    } else if (grammarAvg >= 60) {
        grammarFeedback = 'Fair grammar skills. Focus on sentence structure and punctuation.';
    } else if (grammarAvg >= 40) {
        grammarFeedback = 'Grammar needs improvement. Practice speaking clearly and using proper sentence structure.';
    } else {
        grammarFeedback = 'Significant grammar improvement needed. Consider language practice and training.';
    }
    
    if (interviewSkipped > 0) {
        grammarFeedback += ` Note: ${interviewSkipped} interview question(s) were skipped.`;
    }
    
    grammarFeedbackElem.textContent = grammarFeedback;

    // Comprehensive summary with detailed breakdown
    summaryElem.innerHTML = `
        <div style="background: rgba(255,255,255,0.05); padding: 1.5em; border-radius: 10px; margin-bottom: 1em;">
            <h3 style="margin-top: 0; color: #63b3ed;">Performance Overview</h3>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1em; margin-bottom: 1em;">
                <div style="background: rgba(16, 185, 129, 0.1); padding: 1em; border-radius: 8px; border-left: 4px solid #10b981;">
                    <strong>Technical Round</strong><br>
                    ${mcqScore}/${mcqTotal} (${mcqTotalPercentage.toFixed(1)}%)<br>
                    <small>Skipped: ${mcqSkipped}</small>
                </div>
                <div style="background: rgba(99, 179, 237, 0.1); padding: 1em; border-radius: 8px; border-left: 4px solid #63b3ed;">
                    <strong>Interview Round</strong><br>
                    ${grammarAvg}/100 (Grammar)<br>
                    <small>Skipped: ${interviewSkipped}</small>
                </div>
            </div>
        </div>
        
        <div style="background: rgba(255,255,255,0.05); padding: 1.5em; border-radius: 10px; margin-bottom: 1em;">
            <h4 style="margin-top: 0; color: #f59e0b;">Areas for Improvement</h4>
            <ul style="margin: 0; padding-left: 1.5em;">
                ${grammarIssues.length > 0 ? grammarIssues.map(issue => `<li style="margin-bottom: 0.5em;">${issue}</li>`).join('') : '<li>No specific grammar issues identified</li>'}
                ${mcqSkipped > 0 ? `<li style="color: #f59e0b;">Consider attempting all technical questions (${mcqSkipped} skipped)</li>` : ''}
                ${interviewSkipped > 0 ? `<li style="color: #f59e0b;">Participate in all interview questions (${interviewSkipped} skipped)</li>` : ''}
            </ul>
        </div>
        
        <div style="background: rgba(255,255,255,0.05); padding: 1.5em; border-radius: 10px;">
            <h4 style="margin-top: 0; color: #10b981;">Detailed Grammar Analysis</h4>
            <div style="display: grid; gap: 0.8em;">
                ${grammarDetails.map(detail => `
                    <div style="background: rgba(255,255,255,0.05); padding: 1em; border-radius: 6px; border-left: 3px solid ${detail.skipped ? '#f59e0b' : detail.score >= 80 ? '#10b981' : detail.score >= 60 ? '#f59e0b' : '#ef4444'};">
                        <strong>Question ${detail.question}:</strong> 
                        ${detail.skipped ? 'Skipped' : `${detail.score}/100`}<br>
                        <small style="color: #9ca3af;">${detail.feedback}</small>
                        ${!detail.skipped && detail.wordCount > 0 ? `<br><small>Words: ${detail.wordCount} | Sentences: ${detail.sentenceCount}</small>` : ''}
                    </div>
                `).join('')}
            </div>
        </div>
    `;

    // PDF Download report feature using jsPDF with enhanced content
    const downloadBtn = document.getElementById('download-report');
    if (downloadBtn) {
        downloadBtn.onclick = function() {
            // Load jsPDF if not already loaded
            if (typeof window.jspdf === 'undefined' && typeof window.jsPDF === 'undefined') {
                const script = document.createElement('script');
                script.src = 'https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js';
                script.onload = () => generatePDF();
                document.body.appendChild(script);
            } else {
                generatePDF();
            }
        };
    }

    function generatePDF() {
        const { jsPDF } = window.jspdf || window;
        const doc = new jsPDF();
        let y = 20;
        
        // Header
        doc.setFontSize(18);
        doc.text('SkillUp Assessment Report', 20, y);
        y += 15;
        
        doc.setFontSize(12);
        doc.text(`Generated: ${new Date().toLocaleDateString()}`, 20, y);
        y += 15;
        
        // Technical Performance
        doc.setFontSize(14);
        doc.text('Technical Performance', 20, y);
        y += 10;
        doc.setFontSize(10);
        doc.text(`Score: ${mcqScore}/${mcqTotal} (${mcqTotalPercentage.toFixed(1)}%)`, 25, y);
        y += 6;
        doc.text(`Answered: ${mcqAnswered} | Skipped: ${mcqSkipped}`, 25, y);
        y += 6;
        if (mcqAttempted > 0) {
            doc.text(`Accuracy on attempted: ${mcqPercentage.toFixed(1)}%`, 25, y);
            y += 6;
        }
        doc.text(`Feedback: ${technicalFeedback}`, 25, y, { maxWidth: 160 });
        y += 20;
        
        // Grammar Performance
        if (y > 250) { doc.addPage(); y = 20; }
        doc.setFontSize(14);
        doc.text('Grammar & Communication', 20, y);
        y += 10;
        doc.setFontSize(10);
        doc.text(`Average Score: ${grammarAvg}/100`, 25, y);
        y += 6;
        doc.text(`Interview Questions: Answered ${interviewAnswered} | Skipped ${interviewSkipped}`, 25, y);
        y += 6;
        doc.text(`Feedback: ${grammarFeedback}`, 25, y, { maxWidth: 160 });
        y += 15;
        
        // Detailed Analysis
        grammarDetails.forEach((detail, idx) => {
            if (y > 260) { doc.addPage(); y = 20; }
            doc.text(`Q${detail.question}: ${detail.skipped ? 'Skipped' : detail.score + '/100'}`, 30, y);
            y += 6;
            doc.text(`${detail.feedback}`, 35, y, { maxWidth: 150 });
            y += 8;
        });
        
        doc.save('SkillUp_Assessment_Report.pdf');
    }
});