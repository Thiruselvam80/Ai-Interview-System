import requests
import os

API_URL = 'http://127.0.0.1:5000'
LANGUAGE = 'Python'  # Change as needed

# 1. Generate 15 questions for round 1
resp = requests.post(f'{API_URL}/generate-questions', json={'language': LANGUAGE})
questions_round1 = resp.json()['questions']
print('Round 1 Questions:')
for q in questions_round1:
    print(q)

# 2. Generate 10 interview questions for round 2
resp = requests.post(f'{API_URL}/generate-interview', json={'language': LANGUAGE})
questions_round2 = resp.json()['questions']
print('\nRound 2 Interview Questions:')
for q in questions_round2:
    print(q)

# 3. Simulate answer capture (replace with actual audio file path for real use)
def get_transcript_for_audio(audio_path):
    with open(audio_path, 'rb') as f:
        files = {'audio': f}
        resp = requests.post(f'{API_URL}/answer-audio', files=files)
        return resp.json()['transcript']

# 4. Grammar detection for each transcript
def get_grammar_result(transcript):
    resp = requests.post(f'{API_URL}/grammar-check', json={'text': transcript})
    return resp.json()

# Simulate answers (replace with real audio and transcripts)
technical_results = []
grammar_results = []
for i, q in enumerate(questions_round1 + questions_round2):
    # Simulate transcript (replace with get_transcript_for_audio for real audio)
    transcript = f"This is a sample answer for question {i+1}."
    grammar_result = get_grammar_result(transcript)
    technical_results.append({'question': q['question'], 'score': 1, 'answer': transcript})
    grammar_results.append(grammar_result)

# 5. Generate report
# For simplicity, use the last grammar result as summary
grammar_summary = grammar_results[-1] if grammar_results else {}
resp = requests.post(f'{API_URL}/generate-report', json={
    'technical': technical_results,
    'grammar': grammar_summary
})
report = resp.json()
print('\nFinal Report:')
print(report)
