function selectCourse(course) {
    localStorage.setItem('selectedCourse', course);
    window.location.href = 'course-detail.html?course=' + course;
}