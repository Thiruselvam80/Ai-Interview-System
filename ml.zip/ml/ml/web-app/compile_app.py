#!/usr/bin/env python3
"""
ML-Powered Interview Application - Compilation & Deployment Script
================================================================

This script compiles and starts the complete ML-powered interview application
with unique question generation, dark theme UI, and comprehensive testing.

Features:
- ML-based question generation for Python, Java, JavaScript, C
- Professional dark theme UI with animations
- Real-time speech recognition and grammar checking
- Comprehensive reporting system
- Multi-language support with unique questions per session
"""

import os
import sys
import subprocess
import time
import json
import requests
from pathlib import Path

class MLInterviewCompiler:
    def __init__(self):
        # Use the web-app folder as the base directory so paths resolve to this project
        self.base_dir = Path(__file__).parent
        self.src_dir = self.base_dir / "src"
        self.public_dir = self.base_dir / "public"
        self.required_packages = [
            "flask", "requests", "hashlib", "datetime", 
            "json", "os", "tempfile", "pathlib"
        ]
        self.processes = []
        
    def print_header(self):
        """Print compilation header"""
        print("=" * 70)
        print("🚀 ML-POWERED INTERVIEW APPLICATION COMPILER")
        print("=" * 70)
        print("📅 Compilation Date:", time.strftime("%Y-%m-%d %H:%M:%S"))
        print("📂 Base Directory:", self.base_dir.absolute())
        print("🔧 Python Version:", sys.version.split()[0])
        print("-" * 70)
        
    def check_dependencies(self):
        """Check if all required Python packages are available"""
        print("🔍 Checking Dependencies...")
        
        missing_packages = []
        for package in self.required_packages:
            try:
                if package == "hashlib":
                    import hashlib
                elif package == "datetime":
                    import datetime
                elif package == "json":
                    import json
                elif package == "os":
                    import os
                elif package == "tempfile":
                    import tempfile
                elif package == "pathlib":
                    import pathlib
                elif package == "flask":
                    import flask
                elif package == "requests":
                    import requests
                print(f"  ✅ {package}")
            except ImportError:
                missing_packages.append(package)
                print(f"  ❌ {package}")
        
        if missing_packages:
            print(f"\n⚠️ Missing packages: {', '.join(missing_packages)}")
            print("Installing missing packages...")
            for package in missing_packages:
                if package not in ["hashlib", "datetime", "json", "os", "tempfile", "pathlib"]:
                    subprocess.run([sys.executable, "-m", "pip", "install", package])
        
        print("✅ Dependencies check complete!\n")
        
    def validate_file_structure(self):
        """Validate that all required files exist"""
        print("📁 Validating File Structure...")
        
        required_files = {
            "Backend Files": [
                self.src_dir / "ml_api.py",
                self.src_dir / "advanced_question_generator.py",
                self.src_dir / "grammar_detection.py",
                self.src_dir / "report_generation.py"
            ],
            "Frontend Files": [
                self.base_dir / "server.js",
                self.public_dir / "index.html",
                self.public_dir / "test.html",
                self.public_dir / "test-launcher.html",
                self.public_dir / "courses.html",
                self.public_dir / "js" / "test.js"
            ]
        }
        
        all_valid = True
        for category, files in required_files.items():
            print(f"\n  📂 {category}:")
            for file_path in files:
                if file_path.exists():
                    print(f"    ✅ {file_path.name}")
                else:
                    print(f"    ❌ {file_path.name} - MISSING!")
                    all_valid = False
        
        if all_valid:
            print("\n✅ File structure validation complete!")
        else:
            print("\n❌ Some required files are missing!")
            return False
        
        return True
        
    def start_flask_server(self):
        """Start the Flask ML API server"""
        print("🔥 Starting Flask ML API Server...")
        
        flask_cmd = [sys.executable, str(self.src_dir / "ml_api.py")]
        
        try:
            process = subprocess.Popen(
                flask_cmd,
                cwd=str(self.src_dir),
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            self.processes.append(('Flask API', process))
            
            # Wait a moment for server to start
            time.sleep(3)
            
            # Test if server is responding
            try:
                response = requests.get("http://127.0.0.1:5000/", timeout=5)
                if response.status_code == 200:
                    print("✅ Flask ML API Server started successfully on port 5000")
                    return True
                else:
                    print(f"⚠️ Flask server responded with status {response.status_code}")
            except requests.exceptions.RequestException:
                print("⚠️ Flask server not responding yet, but process started")
                
        except Exception as e:
            print(f"❌ Failed to start Flask server: {e}")
            return False
            
        return True
        
    def start_node_server(self):
        """Start the Node.js web server"""
        print("🌐 Starting Node.js Web Server...")
        
        try:
            process = subprocess.Popen(
                ["node", "server.js"],
                cwd=str(self.base_dir),
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )
            self.processes.append(('Node.js Web', process))
            
            # Wait a moment for server to start
            time.sleep(2)
            
            # Test if server is responding
            try:
                response = requests.get("http://localhost:3000", timeout=5)
                if response.status_code == 200:
                    print("✅ Node.js Web Server started successfully on port 3000")
                    return True
                else:
                    print(f"⚠️ Node.js server responded with status {response.status_code}")
            except requests.exceptions.RequestException:
                print("⚠️ Node.js server not responding yet, but process started")
                
        except Exception as e:
            print(f"❌ Failed to start Node.js server: {e}")
            return False
            
        return True
        
    def test_ml_question_generation(self):
        """Test the ML question generation system"""
        print("🧪 Testing ML Question Generation...")
        
        test_languages = ['python', 'java', 'javascript', 'c']
        
        for lang in test_languages:
            try:
                response = requests.post(
                    'http://127.0.0.1:5000/generate-questions',
                    json={'language': lang, 'num_questions': 3, 'use_ml': True},
                    timeout=10
                )
                
                if response.status_code == 200:
                    data = response.json()
                    if data.get('status') == 'success':
                        print(f"  ✅ {lang.upper()}: {len(data.get('questions', []))} questions generated")
                    else:
                        print(f"  ⚠️ {lang.upper()}: API returned {data.get('status', 'unknown status')}")
                else:
                    print(f"  ❌ {lang.upper()}: HTTP {response.status_code}")
                    
            except Exception as e:
                print(f"  ❌ {lang.upper()}: {e}")
        
        print("✅ ML question generation testing complete!")
        
    def display_compilation_summary(self):
        """Display final compilation summary"""
        print("\n" + "=" * 70)
        print("🎉 COMPILATION COMPLETE!")
        print("=" * 70)
        
        print("\n🚀 RUNNING SERVICES:")
        for service_name, process in self.processes:
            if process.poll() is None:  # Process is still running
                print(f"  ✅ {service_name} - Running (PID: {process.pid})")
            else:
                print(f"  ❌ {service_name} - Stopped")
        
        print("\n🌐 ACCESS POINTS:")
        print("  📱 Main Application: http://localhost:3000")
        print("  🚀 Test Launcher: http://localhost:3000/test-launcher.html")
        print("  📝 Direct Test: http://localhost:3000/test.html")
        print("  🔧 API Health: http://127.0.0.1:5000")
        
        print("\n✨ FEATURES AVAILABLE:")
        print("  🤖 ML-powered question generation for 4 languages")
        print("  🎨 Professional dark theme UI with animations")
        print("  📊 Difficulty-based question distribution")
        print("  🔄 Unique questions per session (no duplicates)")
        print("  🎯 Language-specific content and explanations")
        print("  📈 Comprehensive reporting system")
        print("  🎙️ Voice-based interview rounds")
        print("  📝 Grammar checking and analysis")
        
        print("\n🛠️ DEVELOPMENT INFO:")
        print(f"  📂 Project Directory: {self.base_dir}")
        print(f"  🐍 Python Backend: {self.src_dir}")
        print(f"  🌐 Web Frontend: {self.public_dir}")
        
        print("\n" + "=" * 70)
        
    def cleanup(self):
        """Cleanup processes on exit"""
        print("\n🧹 Cleaning up processes...")
        for service_name, process in self.processes:
            if process.poll() is None:
                print(f"  🛑 Stopping {service_name}...")
                process.terminate()
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    process.kill()
        
    def run(self):
        """Main compilation and startup routine"""
        try:
            self.print_header()
            
            # Step 1: Check dependencies
            self.check_dependencies()
            
            # Step 2: Validate file structure
            if not self.validate_file_structure():
                print("❌ Compilation aborted due to missing files!")
                return False
            
            # Step 3: Start Flask server
            if not self.start_flask_server():
                print("❌ Failed to start Flask server!")
                return False
            
            # Step 4: Start Node.js server
            if not self.start_node_server():
                print("❌ Failed to start Node.js server!")
                return False
            
            # Step 5: Test ML system
            time.sleep(2)  # Allow servers to fully start
            self.test_ml_question_generation()
            
            # Step 6: Display summary
            self.display_compilation_summary()
            
            # Step 7: Keep running
            print("\n⏰ Servers are running. Press Ctrl+C to stop.")
            try:
                while True:
                    time.sleep(1)
            except KeyboardInterrupt:
                print("\n\n🛑 Shutdown requested by user...")
                
        except Exception as e:
            print(f"\n❌ Compilation error: {e}")
            return False
            
        finally:
            self.cleanup()
            
        return True

if __name__ == "__main__":
    compiler = MLInterviewCompiler()
    success = compiler.run()
    sys.exit(0 if success else 1)