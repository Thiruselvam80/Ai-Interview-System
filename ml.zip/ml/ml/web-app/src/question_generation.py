
import json
import random
import hashlib
from typing import List, Dict, Any

class AdvancedQuestionGenerator:
    def __init__(self):
        self.language_templates = {
            'python': {
                'easy': [
                    {
                        'template': 'What is the output of the following Python code?\n```python\n{code}\n```',
                        'concepts': ['data_types', 'variables', 'basic_operations'],
                        'code_examples': [
                            'x = 5\ny = 3\nprint(x + y)',
                            'name = "Python"\nprint(len(name))',
                            'numbers = [1, 2, 3]\nprint(numbers[1])'
                        ]
                    },
                    {
                        'template': 'Which of the following is the correct way to {action} in Python?',
                        'concepts': ['syntax', 'built_ins'],
                        'actions': ['create a list', 'define a function', 'import a module', 'create a dictionary']
                    },
                    {
                        'template': 'What data type is returned by the {function} function in Python?',
                        'concepts': ['built_in_functions', 'data_types'],
                        'functions': ['len()', 'type()', 'input()', 'range()']
                    }
                ],
                'medium': [
                    {
                        'template': 'What is the difference between {concept1} and {concept2} in Python?',
                        'concepts': ['advanced_concepts'],
                        'comparisons': [
                            ('list', 'tuple'), ('set', 'dictionary'), ('is', '=='), ('append()', 'extend()')
                        ]
                    },
                    {
                        'template': 'Which design pattern is demonstrated in this Python code?\n```python\n{code}\n```',
                        'concepts': ['design_patterns', 'oop'],
                        'code_examples': [
                            'class Singleton:\n    _instance = None\n    def __new__(cls):\n        if cls._instance is None:\n            cls._instance = super().__new__(cls)\n        return cls._instance',
                            'class Animal:\n    def sound(self): pass\nclass Dog(Animal):\n    def sound(self): return "Woof"'
                        ]
                    },
                    {
                        'template': 'What will happen when this Python code is executed?\n```python\n{code}\n```',
                        'concepts': ['error_handling', 'exceptions'],
                        'code_examples': [
                            'try:\n    x = 10 / 0\nexcept ZeroDivisionError:\n    print("Cannot divide by zero")',
                            'def func():\n    return x\nx = 5\nprint(func())'
                        ]
                    }
                ],
                'hard': [
                    {
                        'template': 'Analyze the time complexity of this Python algorithm:\n```python\n{code}\n```',
                        'concepts': ['algorithms', 'complexity'],
                        'code_examples': [
                            'def bubble_sort(arr):\n    for i in range(len(arr)):\n        for j in range(0, len(arr)-i-1):\n            if arr[j] > arr[j+1]:\n                arr[j], arr[j+1] = arr[j+1], arr[j]',
                            'def binary_search(arr, x):\n    low, high = 0, len(arr) - 1\n    while low <= high:\n        mid = (high + low) // 2\n        if arr[mid] == x: return mid\n        elif arr[mid] < x: low = mid + 1\n        else: high = mid - 1'
                        ]
                    },
                    {
                        'template': 'What is the most efficient way to {optimization} in Python?',
                        'concepts': ['optimization', 'performance'],
                        'optimizations': ['remove duplicates from a large list', 'find common elements in two lists', 'count occurrences in a string', 'sort a dictionary by values']
                    }
                ]
            },
            'java': {
                'easy': [
                    {
                        'template': 'What is the output of this Java code?\n```java\n{code}\n```',
                        'concepts': ['data_types', 'variables'],
                        'code_examples': [
                            'int x = 10;\nint y = 3;\nSystem.out.println(x / y);',
                            'String str = "Java";\nSystem.out.println(str.length());',
                            'boolean flag = true;\nSystem.out.println(!flag);'
                        ]
                    },
                    {
                        'template': 'Which keyword is used to {action} in Java?',
                        'concepts': ['keywords', 'syntax'],
                        'actions': ['create a constant variable', 'inherit from a class', 'prevent method overriding', 'handle exceptions']
                    },
                    {
                        'template': 'What is the correct syntax for {construct} in Java?',
                        'concepts': ['syntax', 'constructs'],
                        'constructs': ['creating an array', 'defining a method', 'creating a class', 'using a for loop']
                    }
                ],
                'medium': [
                    {
                        'template': 'What is the difference between {concept1} and {concept2} in Java?',
                        'concepts': ['oop_concepts'],
                        'comparisons': [
                            ('abstract class', 'interface'), ('overloading', 'overriding'), ('static', 'non-static'), ('final', 'finally')
                        ]
                    },
                    {
                        'template': 'Which Java collection is best suited for {use_case}?',
                        'concepts': ['collections', 'data_structures'],
                        'use_cases': ['storing unique elements', 'maintaining insertion order', 'key-value pairs', 'thread-safe operations']
                    },
                    {
                        'template': 'What design principle does this Java code violate?\n```java\n{code}\n```',
                        'concepts': ['design_principles', 'best_practices'],
                        'code_examples': [
                            'class Calculator {\n    public void add() { /* math */ }\n    public void saveToFile() { /* file I/O */ }\n}',
                            'class Shape {\n    String type;\n    public double area() {\n        if (type.equals("circle")) return 3.14 * r * r;\n        else if (type.equals("rectangle")) return w * h;\n    }\n}'
                        ]
                    }
                ],
                'hard': [
                    {
                        'template': 'Analyze the memory usage pattern of this Java code:\n```java\n{code}\n```',
                        'concepts': ['memory_management', 'gc'],
                        'code_examples': [
                            'List<String> list = new ArrayList<>();\nfor (int i = 0; i < 1000000; i++) {\n    list.add("Item " + i);\n}',
                            'class Node {\n    Node next;\n    String data;\n}\nNode head = new Node();\nNode current = head;\nfor (int i = 0; i < 1000; i++) {\n    current.next = new Node();\n    current = current.next;\n}'
                        ]
                    },
                    {
                        'template': 'What is the time complexity of this Java implementation?\n```java\n{code}\n```',
                        'concepts': ['algorithms', 'complexity'],
                        'code_examples': [
                            'public boolean contains(int[] arr, int target) {\n    for (int i = 0; i < arr.length; i++) {\n        if (arr[i] == target) return true;\n    }\n    return false;\n}',
                            'public void quickSort(int[] arr, int low, int high) {\n    if (low < high) {\n        int pi = partition(arr, low, high);\n        quickSort(arr, low, pi - 1);\n        quickSort(arr, pi + 1, high);\n    }\n}'
                        ]
                    }
                ]
            },
            'javascript': {
                'easy': [
                    {
                        'template': 'What is the output of this JavaScript code?\n```javascript\n{code}\n```',
                        'concepts': ['data_types', 'variables'],
                        'code_examples': [
                            'let x = 5;\nlet y = "5";\nconsole.log(x == y);',
                            'const arr = [1, 2, 3];\nconsole.log(arr.length);',
                            'let name = "JavaScript";\nconsole.log(name.charAt(0));'
                        ]
                    },
                    {
                        'template': 'Which method is used to {action} in JavaScript?',
                        'concepts': ['methods', 'built_ins'],
                        'actions': ['add an element to an array', 'remove the last element from array', 'convert string to number', 'check if value is array']
                    },
                    {
                        'template': 'What does the {operator} operator do in JavaScript?',
                        'concepts': ['operators'],
                        'operators': ['typeof', 'instanceof', 'in', '===']
                    }
                ],
                'medium': [
                    {
                        'template': 'What is the difference between {concept1} and {concept2} in JavaScript?',
                        'concepts': ['comparisons'],
                        'comparisons': [
                            ('let', 'var'), ('null', 'undefined'), ('==', '==='), ('arrow function', 'regular function')
                        ]
                    },
                    {
                        'template': 'What will this JavaScript code return?\n```javascript\n{code}\n```',
                        'concepts': ['closures', 'scope'],
                        'code_examples': [
                            'function outer() {\n  let x = 10;\n  return function inner() {\n    return x;\n  };\n}\nconst fn = outer();\nconsole.log(fn());',
                            'const obj = {\n  name: "Test",\n  getName: function() { return this.name; }\n};\nconst getName = obj.getName;\nconsole.log(getName());'
                        ]
                    },
                    {
                        'template': 'Which Array method should you use to {task}?',
                        'concepts': ['array_methods'],
                        'tasks': ['create a new array with modified elements', 'find the first element that matches condition', 'combine all elements into single value', 'create new array with filtered elements']
                    }
                ],
                'hard': [
                    {
                        'template': 'What is the execution order of this asynchronous JavaScript code?\n```javascript\n{code}\n```',
                        'concepts': ['async', 'event_loop'],
                        'code_examples': [
                            'console.log("1");\nsetTimeout(() => console.log("2"), 0);\nPromise.resolve().then(() => console.log("3"));\nconsole.log("4");',
                            'async function test() {\n  console.log("A");\n  await Promise.resolve();\n  console.log("B");\n}\ntest();\nconsole.log("C");'
                        ]
                    },
                    {
                        'template': 'What memory leak issue exists in this JavaScript code?\n```javascript\n{code}\n```',
                        'concepts': ['memory_management', 'performance'],
                        'code_examples': [
                            'function createHandler() {\n  const largeData = new Array(1000000).fill("data");\n  return function() {\n    console.log("Handler called");\n  };\n}',
                            'const listeners = [];\nfunction addListener() {\n  const element = document.createElement("div");\n  listeners.push(() => element.innerHTML = "test");\n}'
                        ]
                    }
                ]
            },
            'c': {
                'easy': [
                    {
                        'template': 'What will this C program output?\n```c\n{code}\n```',
                        'concepts': ['basics', 'syntax'],
                        'code_examples': [
                            '#include <stdio.h>\nint main() {\n    int x = 5, y = 2;\n    printf("%d", x % y);\n    return 0;\n}',
                            '#include <stdio.h>\nint main() {\n    char str[] = "Hello";\n    printf("%d", strlen(str));\n    return 0;\n}'
                        ]
                    },
                    {
                        'template': 'Which header file is required for {function} in C?',
                        'concepts': ['headers', 'libraries'],
                        'functions': ['printf()', 'malloc()', 'strlen()', 'sqrt()']
                    }
                ],
                'medium': [
                    {
                        'template': 'What is the difference between {concept1} and {concept2} in C?',
                        'concepts': ['memory_concepts'],
                        'comparisons': [
                            ('malloc()', 'calloc()'), ('stack', 'heap'), ('pass by value', 'pass by reference')
                        ]
                    },
                    {
                        'template': 'What potential issue exists in this C code?\n```c\n{code}\n```',
                        'concepts': ['common_errors', 'debugging'],
                        'code_examples': [
                            'char* getString() {\n    char str[100] = "Hello";\n    return str;\n}',
                            'int* ptr = malloc(sizeof(int) * 10);\n*ptr = 5;\n// missing free(ptr);'
                        ]
                    }
                ],
                'hard': [
                    {
                        'template': 'Analyze the memory behavior of this C program:\n```c\n{code}\n```',
                        'concepts': ['memory_management', 'pointers'],
                        'code_examples': [
                            'int** create2DArray(int rows, int cols) {\n    int** arr = malloc(rows * sizeof(int*));\n    for (int i = 0; i < rows; i++) {\n        arr[i] = malloc(cols * sizeof(int));\n    }\n    return arr;\n}'
                        ]
                    }
                ]
            }
        }
        
        self.used_questions = set()
        
    def generate_unique_mcq(self, language: str, difficulty: str) -> Dict[str, Any]:
        """Generate a unique MCQ question for specified language and difficulty"""
        lang_lower = language.lower()
        if lang_lower not in self.language_templates:
            return self._generate_fallback_question(language, difficulty)
            
        templates = self.language_templates[lang_lower].get(difficulty, [])
        if not templates:
            return self._generate_fallback_question(language, difficulty)
            
        # Try up to 10 times to generate a unique question
        for _ in range(10):
            template = random.choice(templates)
            question_data = self._fill_template(template, language, difficulty)
            question_hash = hashlib.md5(question_data['question'].encode()).hexdigest()
            
            if question_hash not in self.used_questions:
                self.used_questions.add(question_hash)
                return question_data
                
        # If all attempts failed, generate fallback
        return self._generate_fallback_question(language, difficulty)
    
    def _fill_template(self, template: Dict, language: str, difficulty: str) -> Dict[str, Any]:
        """Fill template with specific content"""
        question_text = template['template']
        
        # Handle different template types
        if '{code}' in question_text:
            code = random.choice(template['code_examples'])
            question_text = question_text.format(code=code)
            options, correct = self._generate_code_options(code, language, template['concepts'])
            
        elif '{action}' in question_text:
            action = random.choice(template['actions'])
            question_text = question_text.format(action=action)
            options, correct = self._generate_action_options(action, language)
            
        elif '{function}' in question_text:
            function = random.choice(template['functions'])
            question_text = question_text.format(function=function)
            options, correct = self._generate_function_options(function, language)
            
        elif '{concept1}' in question_text and '{concept2}' in question_text:
            concept1, concept2 = random.choice(template['comparisons'])
            question_text = question_text.format(concept1=concept1, concept2=concept2)
            options, correct = self._generate_comparison_options(concept1, concept2, language)
            
        elif '{use_case}' in question_text:
            use_case = random.choice(template['use_cases'])
            question_text = question_text.format(use_case=use_case)
            options, correct = self._generate_use_case_options(use_case, language)
            
        elif '{optimization}' in question_text:
            optimization = random.choice(template['optimizations'])
            question_text = question_text.format(optimization=optimization)
            options, correct = self._generate_optimization_options(optimization, language)
        
        elif '{operator}' in question_text:
            operator = random.choice(template['operators'])
            question_text = question_text.format(operator=operator)
            options, correct = self._generate_operator_options(operator, language)
        
        elif '{task}' in question_text:
            task = random.choice(template['tasks'])
            question_text = question_text.format(task=task)
            options, correct = self._generate_task_options(task, language)
            
        else:
            # Handle other template types
            options, correct = self._generate_generic_options(language, difficulty)
        
        return {
            'question': question_text,
            'options': options,
            'answer': correct,
            'difficulty': difficulty,
            'language': language,
            'concepts': template.get('concepts', [])
        }
    
    def _generate_code_options(self, code: str, language: str, concepts: List[str]) -> tuple:
        """Generate options for code-based questions"""
        if language.lower() == 'python':
            if 'x = 5\ny = 3\nprint(x + y)' in code:
                return ['8', '5', '3', 'Error'], '8'
            elif 'len(name)' in code:
                return ['6', '5', '7', 'Error'], '6'
            elif 'numbers[1]' in code:
                return ['1', '2', '3', 'Error'], '2'
            elif 'x = 10 / 0' in code:
                return ['Infinity', '0', 'Cannot divide by zero', 'Error'], 'Cannot divide by zero'
        
        elif language.lower() == 'java':
            if 'x / y' in code and 'int' in code:
                return ['3.33', '3', '4', 'Error'], '3'
            elif 'str.length()' in code:
                return ['4', '5', '3', 'Error'], '4'
            elif '!flag' in code:
                return ['true', 'false', '1', 'Error'], 'false'
        
        elif language.lower() == 'c':
            if 'x % y' in code:
                return ['1', '2', '0', '5'], '1'
            elif 'strlen(str)' in code:
                return ['5', '4', '6', 'Error'], '5'
        
        elif language.lower() == 'javascript':
            if 'x == y' in code and '"5"' in code:
                return ['true', 'false', 'undefined', 'Error'], 'true'
            elif 'arr.length' in code:
                return ['3', '2', '4', 'undefined'], '3'
            elif 'charAt(0)' in code:
                return ['"J"', '"a"', '"JavaScript"', 'undefined'], '"J"'
            elif 'return x;' in code and 'function inner' in code:
                return ['10', 'undefined', 'Error', 'null'], '10'
            elif 'this.name' in code and 'getName = obj.getName' in code:
                return ['undefined', '"Test"', 'Error', 'null'], 'undefined'
        
        return ['Option A', 'Option B', 'Option C', 'Option D'], 'Option A'
    
    def _generate_action_options(self, action: str, language: str) -> tuple:
        """Generate options for action-based questions"""
        if language.lower() == 'python':
            if 'create a list' in action:
                return ['list = []', 'list = {}', 'list = ()', 'list = ""'], 'list = []'
            elif 'define a function' in action:
                return ['def function():', 'function def():', 'define function():', 'func function():'], 'def function():'
        
        elif language.lower() == 'java':
            if 'create a constant' in action:
                return ['final', 'const', 'static', 'immutable'], 'final'
            elif 'inherit from a class' in action:
                return ['extends', 'inherits', 'implements', 'derives'], 'extends'
        
        elif language.lower() == 'javascript':
            if 'add an element to an array' in action:
                return ['push()', 'add()', 'append()', 'insert()'], 'push()'
            elif 'remove the last element' in action:
                return ['pop()', 'remove()', 'delete()', 'splice()'], 'pop()'
            elif 'convert string to number' in action:
                return ['parseInt()', 'toString()', 'valueOf()', 'convert()'], 'parseInt()'
            elif 'check if value is array' in action:
                return ['Array.isArray()', 'typeof', 'instanceof Array', 'isArray()'], 'Array.isArray()'
        
        return ['Option A', 'Option B', 'Option C', 'Option D'], 'Option A'
    
    def _generate_function_options(self, function: str, language: str) -> tuple:
        """Generate options for function-based questions"""
        if 'len()' in function:
            return ['int', 'string', 'float', 'boolean'], 'int'
        elif 'type()' in function:
            return ['type object', 'string', 'class', 'None'], 'type object'
        elif 'input()' in function:
            return ['string', 'int', 'any', 'None'], 'string'
        elif 'range()' in function:
            return ['range object', 'list', 'tuple', 'iterator'], 'range object'
        
        return ['Option A', 'Option B', 'Option C', 'Option D'], 'Option A'
    
    def _generate_comparison_options(self, concept1: str, concept2: str, language: str) -> tuple:
        """Generate options for comparison questions"""
        if concept1 == 'list' and concept2 == 'tuple':
            return [
                'Lists are mutable, tuples are immutable',
                'Lists are immutable, tuples are mutable', 
                'No difference',
                'Lists are faster than tuples'
            ], 'Lists are mutable, tuples are immutable'
        
        elif concept1 == 'abstract class' and concept2 == 'interface':
            return [
                'Abstract classes can have constructors, interfaces cannot',
                'Interfaces can have constructors, abstract classes cannot',
                'No difference',
                'Both are exactly the same'
            ], 'Abstract classes can have constructors, interfaces cannot'
        
        return ['Option A', 'Option B', 'Option C', 'Option D'], 'Option A'
    
    def _generate_use_case_options(self, use_case: str, language: str) -> tuple:
        """Generate options for use case questions"""
        if 'unique elements' in use_case:
            return ['HashSet', 'ArrayList', 'LinkedList', 'HashMap'], 'HashSet'
        elif 'insertion order' in use_case:
            return ['LinkedHashMap', 'HashMap', 'TreeMap', 'HashSet'], 'LinkedHashMap'
        elif 'key-value pairs' in use_case:
            return ['HashMap', 'ArrayList', 'LinkedList', 'HashSet'], 'HashMap'
        elif 'thread-safe' in use_case:
            return ['ConcurrentHashMap', 'HashMap', 'ArrayList', 'LinkedList'], 'ConcurrentHashMap'
        
        return ['Option A', 'Option B', 'Option C', 'Option D'], 'Option A'
    
    def _generate_optimization_options(self, optimization: str, language: str) -> tuple:
        """Generate options for optimization questions"""
        if 'remove duplicates' in optimization:
            return ['set(list)', 'for loop with if', 'nested loops', 'manual checking'], 'set(list)'
        elif 'common elements' in optimization:
            return ['set intersection', 'nested loops', 'manual comparison', 'sorting both'], 'set intersection'
        
        return ['Option A', 'Option B', 'Option C', 'Option D'], 'Option A'
    
    def _generate_operator_options(self, operator: str, language: str) -> tuple:
        """Generate options for operator questions"""
        if operator == 'typeof':
            return ['Returns the type of a variable', 'Compares two values', 'Converts type', 'Checks existence'], 'Returns the type of a variable'
        elif operator == 'instanceof':
            return ['Checks if object is instance of class', 'Compares values', 'Creates instance', 'Deletes object'], 'Checks if object is instance of class'
        elif operator == 'in':
            return ['Checks if property exists in object', 'Includes value in array', 'Inputs value', 'None of above'], 'Checks if property exists in object'
        elif operator == '===':
            return ['Strict equality check', 'Assignment', 'Loose equality', 'Not equal'], 'Strict equality check'
        
        return ['Option A', 'Option B', 'Option C', 'Option D'], 'Option A'
    
    def _generate_task_options(self, task: str, language: str) -> tuple:
        """Generate options for task-based questions"""
        if 'create a new array with modified elements' in task:
            return ['map()', 'forEach()', 'filter()', 'reduce()'], 'map()'
        elif 'find the first element that matches condition' in task:
            return ['find()', 'filter()', 'some()', 'every()'], 'find()'
        elif 'combine all elements into single value' in task:
            return ['reduce()', 'map()', 'filter()', 'forEach()'], 'reduce()'
        elif 'create new array with filtered elements' in task:
            return ['filter()', 'map()', 'reduce()', 'some()'], 'filter()'
        
        return ['Option A', 'Option B', 'Option C', 'Option D'], 'Option A'
    
    def _generate_generic_options(self, language: str, difficulty: str) -> tuple:
        """Generate generic options when specific logic doesn't apply"""
        return [
            f'{language} concept A',
            f'{language} concept B', 
            f'{language} concept C',
            f'{language} concept D'
        ], f'{language} concept A'
    
    def _generate_fallback_question(self, language: str, difficulty: str) -> Dict[str, Any]:
        """Generate fallback question when templates fail"""
        fallback_questions = {
            'easy': f"What is a fundamental concept in {language} programming?",
            'medium': f"Which best practice is recommended for {language} development?", 
            'hard': f"What is an advanced optimization technique in {language}?"
        }
        
        return {
            'question': fallback_questions.get(difficulty, f"What is important in {language}?"),
            'options': [
                f'{language} Option A',
                f'{language} Option B',
                f'{language} Option C', 
                f'{language} Option D'
            ],
            'answer': f'{language} Option A',
            'difficulty': difficulty,
            'language': language,
            'concepts': ['general']
        }

def generate_questions_model(language: str, num_questions: int, mode: str = 'normal') -> List[Dict[str, Any]]:
    """Enhanced question generation with unique, language-specific questions"""
    generator = AdvancedQuestionGenerator()
    questions = []
    
    if mode == 'normal':
        # Distribute questions across difficulty levels
        difficulties = ['easy'] * 5 + ['medium'] * 6 + ['hard'] * 4
        if num_questions != 15:
            # Adjust distribution for different numbers
            easy_count = max(1, num_questions // 3)
            hard_count = max(1, num_questions // 5)
            medium_count = num_questions - easy_count - hard_count
            difficulties = ['easy'] * easy_count + ['medium'] * medium_count + ['hard'] * hard_count
        
        # Shuffle to randomize order
        random.shuffle(difficulties)
        
        for i in range(min(num_questions, len(difficulties))):
            difficulty = difficulties[i]
            question_data = generator.generate_unique_mcq(language, difficulty)
            questions.append(question_data)
    
    else:  # interview mode
        for i in range(num_questions):
            questions.append({
                'question': f"Explain a complex {language} concept you've worked with in a real project.",
                'difficulty': 'interview',
                'language': language,
                'concepts': ['practical_experience']
            })
    
    return questions
